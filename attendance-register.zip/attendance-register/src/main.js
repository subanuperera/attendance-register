// Fonts are bundled with the app, so no request goes to outside font services.
import '@fontsource/ibm-plex-sans/400.css';
import '@fontsource/ibm-plex-sans/500.css';
import '@fontsource/ibm-plex-sans/600.css';
import '@fontsource/ibm-plex-mono/500.css';
import '@fontsource-variable/bricolage-grotesque/opsz.css';
import './style.css';
import { start } from './app.js';

// VITE_BACKEND=mock runs a browser-only test copy (npm run dev:mock). Production always uses AWS.
const load = import.meta.env.VITE_BACKEND === 'mock' ? import('./backend-mock.js') : import('./backend-aws.js');
load
  .then((m) => start(m.backend))
  .catch((e) => {
    console.error(e);
    document.getElementById('app').innerHTML =
      '<div class="login"><div class="login-card"><h2>The register could not start</h2><p class="small">Reload the page. If this keeps happening, contact the administrator.</p></div></div>';
  });
