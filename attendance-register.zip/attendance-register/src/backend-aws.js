/* Connects the app to AWS: Amazon Cognito for sign-in and AWS AppSync + DynamoDB for data.
 * amplify_outputs.json is generated automatically by AWS Amplify during each deployment. */
import { Amplify } from 'aws-amplify';
import {
  signIn, confirmSignIn, signOut, fetchAuthSession, getCurrentUser, fetchUserAttributes,
  updatePassword, resetPassword, confirmResetPassword,
} from 'aws-amplify/auth';
import { generateClient } from 'aws-amplify/data';
import outputs from '../amplify_outputs.json';

Amplify.configure(outputs);
const client = generateClient();

const MODELS = ['Setting', 'Programme', 'Student', 'CalendarDay', 'AttendanceSlot', 'StaffProfile'];

/* Turn AppSync/Amplify errors into one shape: {code, message} */
function fail(errors) {
  const e = (errors && errors[0]) || {};
  const t = String(e.errorType || '');
  const err = new Error(e.message || 'The server rejected the change.');
  if (/ConditionalCheckFailed/i.test(t) || /conditional request failed/i.test(err.message)) err.code = 'conflict';
  else if (/Unauthorized/i.test(t) || /Not Authorized/i.test(err.message)) {
    err.code = 'forbidden';
    err.message = 'You do not have permission to make this change.';
  } else if (/Network|fetch|Failed to fetch|timeout/i.test(t + ' ' + err.message)) err.code = 'unavailable';
  return err;
}
async function call(fn) {
  let r;
  try { r = await fn(); }
  catch (e) {
    const err = new Error('Could not reach the server. Check your internet connection.');
    err.code = 'unavailable';
    err.cause = e;
    throw err;
  }
  if (r && r.errors && r.errors.length) throw fail(r.errors);
  return r ? r.data : null;
}

function modelApi(name) {
  const m = client.models[name];
  return {
    create: (item) => call(() => m.create(item)),
    update: (item) => call(() => m.update(item)),
    delete: (id) => call(() => m.delete({ id })),
    observe(onItems, onError) {
      const sub = m.observeQuery().subscribe({
        next: ({ items, isSynced }) => onItems(items, isSynced),
        error: (e) => onError && onError(e),
      });
      return () => sub.unsubscribe();
    },
  };
}

async function identity() {
  try {
    const u = await getCurrentUser();
    const s = await fetchAuthSession();
    const p = (s.tokens && s.tokens.accessToken && s.tokens.accessToken.payload) || {};
    let attrs = {};
    try { attrs = await fetchUserAttributes(); } catch (e) { /* optional */ }
    const email = String(attrs.email || u.signInDetails?.loginId || u.username || '').toLowerCase();
    return { email, name: attrs.name || '', groups: p['cognito:groups'] || [] };
  } catch (e) {
    return null;
  }
}

function authError(e) {
  const n = (e && e.name) || '';
  const err = new Error(
    n === 'NotAuthorizedException' ? (/disabled/i.test(e.message) ? 'This account has been disabled. Ask an administrator.' : 'Email or password is incorrect.')
    : n === 'UserNotFoundException' ? 'Email or password is incorrect.'
    : n === 'LimitExceededException' || n === 'TooManyRequestsException' ? 'Too many attempts. Wait a few minutes and try again.'
    : n === 'InvalidPasswordException' ? 'The password must have at least 8 characters, with upper and lower case letters, a number and a symbol.'
    : n === 'CodeMismatchException' ? 'That code is not correct. Check the email and try again.'
    : n === 'ExpiredCodeException' ? 'That code has expired. Request a new one.'
    : (e && e.message) || 'Sign-in failed.');
  err.code = n;
  return err;
}
const stepOf = (r) => {
  const s = r && r.nextStep && r.nextStep.signInStep;
  if (!s || s === 'DONE') return 'DONE';
  if (s === 'CONFIRM_SIGN_IN_WITH_NEW_PASSWORD_REQUIRED') return 'NEW_PASSWORD';
  if (s === 'RESET_PASSWORD') return 'RESET';
  return s;
};

export const backend = {
  kind: 'aws',
  auth: {
    current: identity,
    async refresh() { await fetchAuthSession({ forceRefresh: true }); return identity(); },
    async signIn(email, password) {
      try { return stepOf(await signIn({ username: email, password })); }
      catch (e) {
        if (e && e.name === 'UserAlreadyAuthenticatedException') { await signOut(); return stepOf(await signIn({ username: email, password })); }
        if (e && e.name === 'PasswordResetRequiredException') return 'RESET';
        throw authError(e);
      }
    },
    async confirmNewPassword(pw) {
      try { return stepOf(await confirmSignIn({ challengeResponse: pw })); } catch (e) { throw authError(e); }
    },
    async signOut() { try { await signOut(); } catch (e) { /* already signed out */ } },
    async changePassword(oldPassword, newPassword) {
      try { await updatePassword({ oldPassword, newPassword }); } catch (e) { throw authError(e); }
    },
    async forgotPassword(email) { try { await resetPassword({ username: email }); } catch (e) { throw authError(e); } },
    async confirmForgot(email, code, pw) {
      try { await confirmResetPassword({ username: email, confirmationCode: code, newPassword: pw }); } catch (e) { throw authError(e); }
    },
    async claimFirstAdmin() { await call(() => client.mutations.claimFirstAdmin({ action: 'claim' })); },
  },
  models: Object.fromEntries(MODELS.map((n) => [n, modelApi(n)])),
  audit: {
    add: (entry) => call(() => client.models.AuditLog.create({ kind: 'log', ...entry })),
    async recent(limit, nextToken) {
      const r = await client.models.AuditLog.listAuditByTime({ kind: 'log' }, { sortDirection: 'DESC', limit, nextToken });
      if (r.errors && r.errors.length) throw fail(r.errors);
      return { items: r.data || [], nextToken: r.nextToken || null };
    },
  },
  staff: (action, args) => call(() => client.mutations.manageStaff({ action, ...args })),
};
