/* Attendance Register: application logic.
 * Storage and sign-in come from the backend passed to start(): AWS in production. */
let B=null;
export function start(backend){B=backend;boot()}
"use strict";
/* ============ utilities ============ */
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const range=(a,b)=>{const r=[];for(let i=a;i<=b;i++)r.push(i);return r};
const fmtPct=v=>v==null||isNaN(v)?'–':(Math.round(v*10)/10).toFixed(1)+'%';
const uid=p=>(p||'x')+'-'+Math.random().toString(36).slice(2,8)+Date.now().toString(36).slice(-3);
const DOW=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];const DOWL=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const D={
  parse(s){const [y,m,d]=s.split('-').map(Number);return Date.UTC(y,m-1,d)},
  fmt(t){return new Date(t).toISOString().slice(0,10)},
  add(s,n){return D.fmt(D.parse(s)+n*864e5)},
  dow(s){return new Date(D.parse(s)).getUTCDay()},
  today(){const n=new Date();return n.getFullYear()+'-'+pad(n.getMonth()+1)+'-'+pad(n.getDate())},
  monday(s){return D.add(s,-((D.dow(s)+6)%7))},
  diff(a,b){return Math.round((D.parse(b)-D.parse(a))/864e5)},
  nice(s){if(!s)return '';const d=new Date(D.parse(s));return DOW[d.getUTCDay()]+' '+pad(d.getUTCDate())+' '+MON[d.getUTCMonth()]},
  long(s){if(!s)return '';const d=new Date(D.parse(s));return pad(d.getUTCDate())+' '+MON[d.getUTCMonth()]+' '+d.getUTCFullYear()},
  short(s){const d=new Date(D.parse(s));return pad(d.getUTCDate())+' '+MON[d.getUTCMonth()]},
  month(s){return s.slice(0,7)},
  monthName(m){const [y,mo]=m.split('-').map(Number);return ['January','February','March','April','May','June','July','August','September','October','November','December'][mo-1]+' '+y}
};
function deepMerge(t,s){for(const k in s){const v=s[k];if(v&&typeof v==='object'&&!Array.isArray(v)){if(!t[k]||typeof t[k]!=='object'||Array.isArray(t[k]))t[k]={};deepMerge(t[k],v)}else t[k]=v}return t}
const clone=o=>JSON.parse(JSON.stringify(o));

/* ============ data store (AWS: AppSync + DynamoDB) ============ */
// The app keeps working with the same document paths as before (programmes/ID, att/PID__DATE …);
// this layer maps them onto the server tables. Attendance is stored per lecture slot so that two
// people saving different slots of the same day can never overwrite each other.
const DATA={settings:{},programmes:{},students:{},users:{},calendar:{},att:{}};
const COLS=['programmes','students','users','calendar','att'];
let VER=0;const MEMO=new Map();
function memo(k,fn){const e=MEMO.get(k);if(e&&e.v===VER)return e.r;const r=fn();MEMO.set(k,{v:VER,r});return r}
const DEF={orgName:'Hospitality Academy',threshold:80,watchBand:85,lateCounts:true,excusedCounts:false,editWindow:3,hab:{streak:2,freq:3,weekday:3,partial:3,late:4,decline:15,s2:4,s3:7}};
function cfg(){const s=DATA.settings||{};return {...DEF,...s,hab:{...DEF.hab,...(s.hab||{})}}}
const pj=(s,d)=>{if(s==null||s==='')return d;if(typeof s!=='string')return s;try{return JSON.parse(s)}catch(e){return d}};
const RAW={Setting:{},Programme:{},Student:{},CalendarDay:{},AttendanceSlot:{},StaffProfile:{}};
const REBUILD={
  Setting(){const r=RAW.Setting.settings;DATA.settings=r?pj(r.data,{}):{}},
  Programme(){DATA.programmes=Object.fromEntries(Object.values(RAW.Programme).map(r=>[r.id,pj(r.data,{})]))},
  Student(){DATA.students=Object.fromEntries(Object.values(RAW.Student).map(r=>[r.id,pj(r.data,{})]))},
  CalendarDay(){const c={};for(const r of Object.values(RAW.CalendarDay)){const x=c[r.pid]||(c[r.pid]={pid:r.pid,days:{}});x.days[r.date]=pj(r.data,{})}DATA.calendar=c},
  AttendanceSlot(){const a={};for(const r of Object.values(RAW.AttendanceSlot)){const k=r.pid+'__'+r.date;const x=a[k]||(a[k]={pid:r.pid,date:r.date,marks:{},meta:{}});x.marks[r.slot]=pj(r.marks,{});const mt=pj(r.meta,null);if(mt)x.meta[r.slot]=mt}DATA.att=a},
  StaffProfile(){DATA.users=Object.fromEntries(Object.values(RAW.StaffProfile).map(r=>[r.id,{name:r.name||'',email:r.email||r.id,username:r.email||r.id,role:r.role||'lecturer',assign:pj(r.assign,[]),active:r.active!==false}]))}
};
function markPending(){document.body.classList.toggle('saving',Store.pending>0);const el=$('#savedot');if(el)el.hidden=Store.pending===0}

const Store={subs:[],pending:0,ready:false,
  async init(){
    this.stop();
    const models=Object.keys(RAW);
    await new Promise((res,rej)=>{
      const synced=new Set();let done=false;
      const t=setTimeout(()=>{if(!done){done=true;rej(new Error('The register took too long to load. Check your internet connection and reload the page.'))}},45000);
      for(const m of models){
        this.subs.push(B.models[m].observe((items,isSynced)=>{
          RAW[m]=Object.fromEntries(items.map(i=>[i.id,i]));REBUILD[m]();VER++;
          if(isSynced&&!synced.has(m)){synced.add(m);if(synced.size===models.length&&!done){done=true;clearTimeout(t);res()}}
          if(done)changed();
        },e=>{console.warn(m,e);toast('Lost the live connection to the register. Reload the page to see the latest changes.',true)}));
      }
    });
    this.ready=true;
  },
  stop(){this.subs.forEach(u=>{try{u()}catch(e){}});this.subs=[];for(const m in RAW){RAW[m]={};REBUILD[m]()}VER++;this.ready=false},
  // Network hiccups are retried automatically (about 10 seconds in total) before an error is shown.
  async retry(fn){let wait=600;for(let i=0;;i++){try{return await fn()}catch(e){if(e&&e.code==='unavailable'&&i<3){await new Promise(r=>setTimeout(r,wait));wait*=2.5;continue}throw e}}},
  async upsert(m,item){
    const known=!!RAW[m][item.id];let res;
    try{res=await this.retry(()=>known?B.models[m].update(item):B.models[m].create(item))}
    catch(e){if(e&&e.code==='conflict')res=await this.retry(()=>known?B.models[m].create(item):B.models[m].update(item));else throw e}
    RAW[m][item.id]={...(RAW[m][item.id]||{}),...item,...(res||{})};REBUILD[m]();VER++;
  },
  async remove(m,id){await this.retry(()=>B.models[m].delete(id));delete RAW[m][id];REBUILD[m]();VER++},
  docOf(path){const [col,id]=path.split('/');if(col==='config')return clone(DATA.settings||{});return DATA[col]&&DATA[col][id]?clone(DATA[col][id]):null},
  async write(path,data,mode,opts){
    opts=opts||{};const [col,id]=path.split('/');
    if(!id)throw new Error('Invalid record name: '+path);
    const before=opts.audit===false?null:this.docOf(path);
    const mergeInto=cur=>mode==='merge'?deepMerge(clone(cur||{}),clone(data)):clone(data);
    this.pending++;markPending();
    try{
      if(col==='config'){await this.upsert('Setting',{id:'settings',data:JSON.stringify(mergeInto(DATA.settings))})}
      else if(col==='programmes'){if(mode==='del')await this.remove('Programme',id);else await this.upsert('Programme',{id,data:JSON.stringify(mergeInto(DATA.programmes[id]))})}
      else if(col==='students'){if(mode==='del')await this.remove('Student',id);else{const d=mergeInto(DATA.students[id]);await this.upsert('Student',{id,pid:d.pid||'',data:JSON.stringify(d)})}}
      else if(col==='users'){if(mode==='del')await this.remove('StaffProfile',id);else{const d=mergeInto(DATA.users[id]);await this.upsert('StaffProfile',{id,email:d.email||id,name:d.name||'',role:d.role||'lecturer',assign:JSON.stringify(d.assign||[]),active:d.active!==false})}}
      else if(col==='calendar'){const pid=id;
        if(mode==='del'){for(const r of Object.values(RAW.CalendarDay).filter(r=>r.pid===pid))await this.remove('CalendarDay',r.id)}
        else{const cur=(DATA.calendar[pid]||{}).days||{};
          for(const [date,v] of Object.entries((data&&data.days)||{})){const d=mode==='merge'?deepMerge(clone(cur[date]||{}),clone(v)):clone(v);await this.upsert('CalendarDay',{id:pid+'__'+date,pid,date,data:JSON.stringify(d)})}}}
      else if(col==='att'){const i=id.lastIndexOf('__');const pid=id.slice(0,i),date=id.slice(i+2);
        if(mode==='del'){for(const r of Object.values(RAW.AttendanceSlot).filter(r=>r.pid===pid&&r.date===date))await this.remove('AttendanceSlot',r.id)}
        else{const cur=DATA.att[id]||{marks:{},meta:{}};
          for(const [sl,mk] of Object.entries((data&&data.marks)||{})){
            const marks=mode==='merge'?{...(cur.marks[sl]||{}),...mk}:mk;const meta=((data.meta||{})[sl])||(mode==='merge'?cur.meta[sl]:null)||null;
            await this.upsert('AttendanceSlot',{id:`${pid}__${date}__${sl}`,pid,date,slot:+sl,marks:JSON.stringify(marks||{}),meta:meta?JSON.stringify(meta):null})}}}
      else throw new Error('Unknown record type: '+col);
    }finally{this.pending--;markPending()}
    changed();
    if(opts.audit!==false)await this.log(mode,path,before,mode==='del'?null:this.docOf(path));
  },
  // Change history: every change is recorded with the version before and after, so it can be undone.
  async log(action,path,before,after){
    const cap=v=>{if(v==null)return null;const s=JSON.stringify(v);return s.length>350000?JSON.stringify({tooLarge:true}):s};
    try{await this.retry(()=>B.audit.add({at:new Date().toISOString(),by:S.me?S.me.id:'',byName:S.me?(S.me.name||S.me.id):'',action,path,before:cap(before),after:cap(after)}))}catch(e){console.warn('history not recorded',e)}
  },
  set(path,data,opts){return this.write(path,data,'set',opts)},
  merge(path,data,opts){return this.write(path,data,'merge',opts)},
  del(path,opts){return this.write(path,null,'del',opts)},
  loadArchived(){} // every record is already loaded
};
let renderTimer=null;
function changed(){VER++;if(!S.booted)return;clearTimeout(renderTimer);renderTimer=setTimeout(()=>{if(S.me){const u=DATA.users[S.me.id];if(u&&u.active===false){logout('This account has been disabled. Ask an administrator.');return}if(u)S.me={...S.me,...u,id:S.me.id,username:S.me.id,role:S.me.role}}renderMain(true)},60)}

/* ============ domain model ============ */
function progList(all){return Object.entries(DATA.programmes).map(([id,p])=>({id,...p})).filter(p=>all||p.status!=='archived').sort((a,b)=>(a.batch||'').localeCompare(b.batch||'')||(a.order||99)-(b.order||99)||a.name.localeCompare(b.name))}
function prog(id){const p=DATA.programmes[id];return p?{id,...p}:null}
function studentsOf(pid,incWithdrawn){return Object.entries(DATA.students).filter(([,s])=>s.pid===pid&&(incWithdrawn||s.status!=='withdrawn')).map(([id,s])=>({id,...s})).sort((a,b)=>(a.no||0)-(b.no||0))}
const sName=s=>s?((s.first||'')+' '+(s.last||'')).trim():'';
const sessionOf=(p,slot)=>slot<=(p.split||Math.ceil(p.slots/2))?'Morning':'Evening';
function progDays(p){return memo('days'+p.id,()=>{
  const cal=(DATA.calendar[p.id]||{}).days||{};
  let from=p.start,to=p.end||D.add(D.monday(p.start),p.weeks*7-1);
  for(const d in cal){if(cal[d].state==='extra'){if(d<from)from=d;if(d>to)to=d}}
  const m0=D.monday(p.start);const out=[];
  for(let d=from;d<=to;d=D.add(d,1)){
    const c=cal[d]||{};const sched=(p.weekdays||[]).includes(D.dow(d))&&d>=p.start&&d<=(p.end||to);
    const on=sched?c.state!=='blocked':c.state==='extra';
    if(on)out.push({date:d,wk:Math.floor(D.diff(m0,d)/7)+1,dow:D.dow(d),slots:(c.slots&&c.slots.length?c.slots.slice().sort((a,b)=>a-b):range(1,p.slots)),lock:c.lock||'',note:c.note||'',extra:!sched});
  }
  return out;
})}
function dayState(p,date){
  const cal=((DATA.calendar[p.id]||{}).days||{})[date]||{};
  const end=p.end||D.add(D.monday(p.start),p.weeks*7-1);
  const sched=(p.weekdays||[]).includes(D.dow(date))&&date>=p.start&&date<=end;
  let st='off';if(sched)st=cal.state==='blocked'?'blocked':'acad';else if(cal.state==='extra')st='extra';
  return {st,sched,lock:cal.lock||'',note:cal.note||'',slots:cal.slots&&cal.slots.length?cal.slots:range(1,p.slots),inRange:date>=p.start&&date<=end};
}
function markRule(p,day){
  const me=S.me;if(!day)return {ok:false,why:'This date is not an academic day for this programme.'};
  const today=D.today();
  if(day.date>today)return {ok:false,why:'This academic day has not happened yet. Attendance opens on the day.'};
  if(me.role==='admin')return {ok:true,why:day.lock==='locked'?'Locked for lecturers. You can still edit as an administrator.':''};
  if(day.lock==='locked')return {ok:false,why:'An administrator has locked this day. Ask the office to reopen it if a correction is needed.'};
  if(day.lock==='open')return {ok:true,why:''};
  const w=cfg().editWindow;if(D.diff(day.date,today)>w)return {ok:false,why:`The ${w}-day marking window for this day has closed. Ask an administrator to reopen it.`};
  return {ok:true,why:''};
}
function isPresent(v,c){return v==='P'||(v==='L'&&c.lateCounts)||(v==='E'&&c.excusedCounts)}
function statusOf(pct,maxPct,c){if(pct==null)return 'none';if(maxPct!=null&&maxPct<c.threshold)return 'critical';if(pct<c.threshold)return 'below';if(pct<c.watchBand)return 'watch';return 'good'}
const STL={good:'On track',watch:'Watch',below:'Below minimum',critical:'Cannot reach minimum',none:'No records yet'};
function pill(st,label){return `<span class="pill st-${st}">${esc(label||STL[st])}</span>`}

function pStats(pid){return memo('ps'+pid,()=>{
  const p=prog(pid);if(!p)return null;const c=cfg();const today=D.today();
  const days=progDays(p);const studs=studentsOf(pid,true);
  const planned=days.reduce((a,d)=>a+d.slots.length,0);
  const target=(p.weeks||0)*((p.weekdays||[]).length)*(p.slots||0);
  const per={};studs.forEach(s=>per[s.id]={s,att:0,abs:0,late:0,exc:0,cond:0,weeks:{},recs:[]});
  let condSlots=0,missing=0;const dinfo=[];let curWk=0;
  const wkAgg={};
  for(const d of days){
    const doc=DATA.att[pid+'__'+d.date];const marks=(doc&&doc.marks)||{};const meta=(doc&&doc.meta)||{};
    const di={...d,conducted:[],missing:[],meta};
    if(d.date<=today)curWk=d.wk;
    for(const sl of d.slots){const m=marks[sl]||{};if(Object.values(m).some(v=>v)){di.conducted.push(sl);condSlots++}else if(d.date<=today){di.missing.push(sl);missing++}}
    dinfo.push(di);
    for(const st of studs){const r=per[st.id];if(!di.conducted.length)continue;const rec={date:d.date,wk:d.wk,dow:d.dow,v:{}};
      for(const sl of di.conducted){const v=(marks[sl]||{})[st.id]||'';rec.v[sl]=v;if(!v)continue;
        r.cond++;const w=r.weeks[d.wk]||(r.weeks[d.wk]={att:0,cond:0});w.cond++;
        const wa=wkAgg[d.wk]||(wkAgg[d.wk]={att:0,cond:0});
        if(st.status!=='withdrawn')wa.cond++;
        if(isPresent(v,c)){r.att++;w.att++;if(st.status!=='withdrawn')wa.att++}else r.abs++;
        if(v==='L')r.late++;if(v==='E')r.exc++;
      }
      r.recs.push(rec);
    }
  }
  const remaining=Math.max(0,planned-condSlots);
  for(const id in per){const r=per[id];
    r.pct=r.cond?r.att/r.cond*100:null;
    r.pctProg=planned?r.att/planned*100:null;
    r.maxPct=planned?Math.min(100,(r.att+remaining)/planned*100):null;
    r.status=statusOf(r.pct,r.maxPct,c);
    r.hab=analyse(r,p,c,curWk);
  }
  const active=studs.filter(s=>s.status!=='withdrawn');
  const sumA=active.reduce((a,s)=>a+per[s.id].att,0),sumC=active.reduce((a,s)=>a+per[s.id].cond,0);
  const dist={good:0,watch:0,below:0,critical:0,none:0};active.forEach(s=>dist[per[s.id].status]++);
  return {p,days:dinfo,planned,target,condSlots,missing,per,studs,active,curWk,avg:sumC?sumA/sumC*100:null,dist,wkAgg,weeksTotal:days.length?days[days.length-1].wk:p.weeks};
})}

function analyse(r,p,c,curWk){
  const h=c.hab;const split=p.split||3;const ind=[];
  const days=r.recs.map(rec=>{
    const vals=Object.entries(rec.v).filter(([,v])=>v);
    const ab=vals.filter(([,v])=>v==='A');
    const mor=vals.filter(([s])=>+s<=split),eve=vals.filter(([s])=>+s>split);
    const all=(arr,f)=>arr.length>0&&arr.every(f);
    return {date:rec.date,wk:rec.wk,dow:rec.dow,n:vals.length,a:ab.length,full:vals.length>0&&ab.length===vals.length,any:ab.length>0,
      skipEve:all(mor,([,v])=>v!=='A')&&all(eve,([,v])=>v==='A'),skipMor:all(mor,([,v])=>v==='A')&&all(eve,([,v])=>v!=='A')};
  });
  let score=0;const add=(pts,k,text)=>{score+=pts;ind.push({pts,k,text})};
  if(r.status==='critical')add(4,'min',`Cannot reach ${c.threshold}% even with full attendance from now on (max ${fmtPct(r.maxPct)})`);
  else if(r.status==='below')add(3,'min',`Attendance to date ${fmtPct(r.pct)} is below the ${c.threshold}% minimum`);
  else if(r.status==='watch')add(1,'min',`Attendance to date ${fmtPct(r.pct)} is close to the minimum`);
  let best={n:0},cur={n:0};
  for(const d of days){if(d.full){if(!cur.n)cur={n:0,from:d.date};cur.n++;cur.to=d.date;if(cur.n>best.n)best={...cur}}else cur={n:0}}
  if(best.n>=h.streak)add(best.n>=h.streak*2?3:2,'streak',`${best.n} consecutive academic days absent (${D.short(best.from)} – ${D.short(best.to)})`);
  const recent=days.filter(d=>d.wk>curWk-4&&d.any).length;
  if(recent>=h.freq)add(2,'freq',`Absent on ${recent} academic days in the last 4 weeks`);
  const dows=[...new Set(days.map(d=>d.dow))];
  if(dows.length>=2){
    const ratios=dows.map(w=>{const ds=days.filter(d=>d.dow===w);const n=ds.filter(d=>d.any).length;return {w,n,t:ds.length,r:ds.length?n/ds.length:0}});
    ratios.sort((a,b)=>b.r-a.r);const top=ratios[0],nxt=ratios[1];
    if(top.n>=h.weekday&&top.r>=.5&&top.r-nxt.r>=.25)add(1,'dow',`Pattern: absent on ${top.n} of ${top.t} ${DOWL[top.w]}s (vs ${Math.round(nxt.r*100)}% of ${DOWL[nxt.w]}s)`);
  }
  const se=days.filter(d=>d.skipEve).length,sm=days.filter(d=>d.skipMor).length;
  if(se+sm>=h.partial){const parts=[];if(se)parts.push(`left after the morning session on ${se} day${se>1?'s':''}`);if(sm)parts.push(`missed the morning session on ${sm} day${sm>1?'s':''}`);add(1,'partial','Partial-day absence: '+parts.join(', '))}
  if(r.late>=h.late)add(1,'late',`${r.late} late arrivals recorded`);
  const wks=Object.keys(r.weeks).map(Number).sort((a,b)=>a-b);
  if(wks.length>=6){const rec=wks.filter(w=>w>curWk-4),old=wks.filter(w=>w<=curWk-4);
    const pc=ws=>{let a=0,t=0;ws.forEach(w=>{a+=r.weeks[w].att;t+=r.weeks[w].cond});return t?a/t*100:null};
    const pr=pc(rec),po=pc(old);if(pr!=null&&po!=null&&po-pr>=h.decline)add(1,'trend',`Attendance fell from ${fmtPct(po)} to ${fmtPct(pr)} over the last 4 weeks`)}
  const stage=(r.status==='critical'||score>=h.s3)?3:score>=h.s2?2:score>=1?1:0;
  const absDays=days.filter(d=>d.any).map(d=>({date:d.date,a:d.a,n:d.n,full:d.full}));
  return {score,stage,ind,absDays,streak:best};
}
const STAGE={1:{t:'Stage 1 · Early alert',a:'Lecturer or mentor speaks with the student and records the reason. Monitor for two weeks.'},
  2:{t:'Stage 2 · Habitual absence',a:'Formal written warning, meeting with the Programme Coordinator and a signed attendance improvement plan.'},
  3:{t:'Stage 3 · Critical',a:'Final warning and academic review with the Head of Programme; inform parent, guardian or sponsor. Eligibility for assessment is at risk.'}};
const stagePill=s=>s?`<span class="pill stage${s}">${STAGE[s].t}</span>`:'';

/* ============ app state & routing ============ */
const S={booted:false,me:null,view:'',mk:{},draft:null,cal:{sel:new Set()},rep:{tab:'register'},hab:{pid:'all',min:2},prog:{}};
const NAV_ADMIN=[['overview','Overview','M3 12h4l3-8 4 16 3-8h4'],['attendance','Take attendance','M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'],['calendar','Academic calendar','M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z'],
  ['sep','Reports'],['reports','Attendance reports','M4 19V5M4 19h16M8 15v-4M12 15V8M16 15v-6'],['absenteeism','Habitual absenteeism','M12 9v4M12 17h.01M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z'],
  ['sep','Administration'],['programmes','Programmes & students','M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8'],['staff','Lecturers & access','M15 7a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1'],['rules','Attendance rules','M12 3v18M3 12h18M5.6 5.6l12.8 12.8'],['data','Import & backup','M12 3v12M7 10l5 5 5-5M4 21h16']];
const NAV_LECT=[['attendance','Take attendance','M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11'],['myclasses','My class progress','M4 19V5M4 19h16M8 15v-4M12 15V8M16 15v-6']];
const icon=d=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${d}"/></svg>`;
function allowedViews(){return (S.me.role==='admin'?NAV_ADMIN:NAV_LECT).filter(n=>n[0]!=='sep').map(n=>n[0])}
function go(v){if(location.hash!=='#'+v)location.hash=v;else{S.view=v;renderMain()}}
window.addEventListener('hashchange',()=>{if(!S.me)return;const v=location.hash.slice(1);if(allowedViews().includes(v)){S.view=v;renderShell();renderMain()}});

/* ============ boot & sign-in (Amazon Cognito) ============ */
const PW_RULE='At least 8 characters, with upper and lower case letters, a number and a symbol.';
const pwOk=p=>/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(p);
function loginCard(inner,id){
  const deco=Array.from({length:36},(_,i)=>`<i class="${[5,14,15,29].includes(i)?'a':''}"></i>`).join('');
  $('#app').innerHTML=`<div class="login"><form class="login-card" id="${id||'loginForm'}" autocomplete="on" novalidate>
    <div class="brand"><div class="brand-mark">AR</div><div><b>${esc(cfg().orgName)}</b><span>Attendance Register</span></div></div>
    <div class="ledger-deco" aria-hidden="true">${deco}</div>${inner}</form></div>`;
}
function renderLoading(msg,isErr){
  loginCard(`<p class="${isErr?'err':'muted small'}">${esc(msg)}</p>${isErr?`<div class="row"><button type="button" class="btn pri" data-act="reload">Try again</button><button type="button" class="btn ghost" data-act="logout">Sign out</button></div>`:''}`,'loadingCard');
}
async function boot(){
  renderLoading('Checking your sign-in…');
  let who=null;try{who=await B.auth.current()}catch(e){who=null}
  if(who)await afterSignIn(who);else renderLogin();
}
async function afterSignIn(who){
  const role=who.groups.includes('ADMINS')?'admin':who.groups.includes('LECTURERS')?'lecturer':null;
  if(!role)return renderNoRole(who);
  renderLoading('Loading programmes, students and attendance records…');
  try{await Store.init()}catch(e){console.error(e);return renderLoading(e.message||'The register could not be loaded.',true)}
  const id=who.email;let prof=DATA.users[id];
  if(!prof&&role==='admin'){try{await Store.set('users/'+id,{email:id,name:who.name||id.split('@')[0],role:'admin',assign:[],active:true},{audit:false})}catch(e){console.warn(e)}prof=DATA.users[id]}
  if(role==='lecturer'&&!prof){Store.stop();await B.auth.signOut();return renderLogin('Your account is not linked to the register yet. Ask an administrator to check Lecturers & access.')}
  S.me={...(prof||{name:who.name||id,email:id,assign:[]}),id,username:id,role};
  S.booted=true;enter();
}
function renderLogin(msg,info){
  S.me=null;S.booted=false;
  loginCard(`<div><h2>Sign in</h2><p class="muted small">Use the email address your administrator registered for you.</p></div>
    <div class="field"><label for="li-user">Email</label><input type="email" id="li-user" autocomplete="username" autocapitalize="none" required></div>
    <div class="field"><label for="li-pass">Password</label><input type="password" id="li-pass" autocomplete="current-password" required></div>
    ${info?`<div class="notice info">${esc(info)}</div>`:''}<div class="err" id="li-err" role="alert">${esc(msg||'')}</div>
    <button class="btn pri" type="submit" id="li-go">Sign in</button>
    <button class="btn ghost sm" type="button" data-act="forgot">Forgot your password?</button>`);
  $('#loginForm').addEventListener('submit',async e=>{
    e.preventDefault();const email=$('#li-user').value.trim().toLowerCase(),pw=$('#li-pass').value;
    if(!email||!pw){$('#li-err').textContent='Enter your email and password.';return}
    $('#li-go').disabled=true;$('#li-err').textContent='';
    try{const step=await B.auth.signIn(email,pw);
      if(step==='NEW_PASSWORD')return renderNewPassword();
      if(step==='RESET')return renderForgot(email,'An administrator has asked you to reset your password.');
      if(step!=='DONE')throw new Error('This sign-in step is not supported: '+step);
      const who=await B.auth.current();if(!who)throw new Error('Sign-in did not complete. Try again.');await afterSignIn(who);
    }catch(er){$('#li-err').textContent=er.message||'Sign-in failed.';$('#li-go').disabled=false}
  });
}
function renderNewPassword(){
  loginCard(`<div><h2>Choose your password</h2><p class="muted small">You signed in with a temporary password. Choose your own to continue.</p></div>
    <div class="field"><label for="np-1">New password</label><input type="password" id="np-1" autocomplete="new-password" required><span class="hint">${PW_RULE}</span></div>
    <div class="field"><label for="np-2">Repeat new password</label><input type="password" id="np-2" autocomplete="new-password" required></div>
    <div class="err" id="np-err" role="alert"></div><button class="btn pri" type="submit" id="np-go">Save and continue</button>
    <button class="btn ghost sm" type="button" data-act="logout">Cancel</button>`,'npForm');
  $('#npForm').addEventListener('submit',async e=>{e.preventDefault();const a=$('#np-1').value;
    if(!pwOk(a)){$('#np-err').textContent=PW_RULE;return}if(a!==$('#np-2').value){$('#np-err').textContent='The two passwords don’t match.';return}
    $('#np-go').disabled=true;
    try{const step=await B.auth.confirmNewPassword(a);if(step!=='DONE')throw new Error('Sign-in did not complete. Try again.');const who=await B.auth.current();await afterSignIn(who)}
    catch(er){$('#np-err').textContent=er.message;$('#np-go').disabled=false}});
}
function renderForgot(email,note){
  loginCard(`<div><h2>Reset your password</h2><p class="muted small">${esc(note||'We’ll email you a code to set a new password.')}</p></div>
    <div class="field"><label for="fp-email">Email</label><input type="email" id="fp-email" value="${esc(email||'')}" required></div>
    <div class="err" id="fp-err" role="alert"></div><button class="btn pri" type="submit" id="fp-go">Email me a code</button>
    <button class="btn ghost sm" type="button" data-act="tologin">Back to sign in</button>`,'fpForm');
  $('#fpForm').addEventListener('submit',async e=>{e.preventDefault();const em=$('#fp-email').value.trim().toLowerCase();if(!em)return;$('#fp-go').disabled=true;
    try{await B.auth.forgotPassword(em);renderForgotCode(em)}catch(er){$('#fp-err').textContent=er.message;$('#fp-go').disabled=false}});
}
function renderForgotCode(email){
  loginCard(`<div><h2>Enter the code</h2><p class="muted small">If ${esc(email)} has an account, a code is on its way. It can take a minute; check spam too.</p></div>
    <div class="field"><label for="fc-code">Code</label><input type="text" id="fc-code" inputmode="numeric" autocomplete="one-time-code" required></div>
    <div class="field"><label for="fc-1">New password</label><input type="password" id="fc-1" autocomplete="new-password" required><span class="hint">${PW_RULE}</span></div>
    <div class="field"><label for="fc-2">Repeat new password</label><input type="password" id="fc-2" autocomplete="new-password" required></div>
    <div class="err" id="fc-err" role="alert"></div><button class="btn pri" type="submit" id="fc-go">Set new password</button>
    <button class="btn ghost sm" type="button" data-act="tologin">Back to sign in</button>`,'fcForm');
  $('#fcForm').addEventListener('submit',async e=>{e.preventDefault();const a=$('#fc-1').value;
    if(!pwOk(a)){$('#fc-err').textContent=PW_RULE;return}if(a!==$('#fc-2').value){$('#fc-err').textContent='The two passwords don’t match.';return}
    $('#fc-go').disabled=true;
    try{await B.auth.confirmForgot(email,$('#fc-code').value.trim(),a);renderLogin('','Password changed. Sign in with your new password.')}catch(er){$('#fc-err').textContent=er.message;$('#fc-go').disabled=false}});
}
function renderNoRole(who){
  loginCard(`<div><h2>Almost there</h2><p class="small">You are signed in as <b>${esc(who.email)}</b>, but this account has not been given a role yet.</p>
    <p class="muted small">If you are setting up the register for the first time, make this account the administrator. This only works while no administrator exists.</p></div>
    <div class="err" id="nr-err" role="alert"></div>
    <button class="btn pri" type="button" data-act="claimadmin">Set up as administrator</button>
    <button class="btn ghost sm" type="button" data-act="logout">Sign out</button>`,'nrForm');
}
async function claimAdmin(){
  const btn=document.querySelector('[data-act="claimadmin"]');if(btn)btn.disabled=true;
  try{await B.auth.claimFirstAdmin();const who=await B.auth.refresh();if(!who||!who.groups.includes('ADMINS'))throw new Error('Sign out and sign in again to finish setting up.');await afterSignIn(who)}
  catch(er){const el=$('#nr-err');if(el)el.textContent=er.message;if(btn)btn.disabled=false}
}
async function logout(msg){S.booted=false;S.me=null;S.draft=null;closeModal();Store.stop();await B.auth.signOut();renderLogin(typeof msg==='string'?msg:'')}
function enter(){
  const v=location.hash.slice(1);
  S.view=allowedViews().includes(v)?v:(S.me.role==='admin'?'overview':'attendance');
  if(location.hash.slice(1)!==S.view)history.replaceState(null,'','#'+S.view);
  $('#app').innerHTML=`<aside id="side"></aside><main id="main"></main>`;
  renderShell();renderMain();
}
function renderShell(){
  const c=cfg();const nav=S.me.role==='admin'?NAV_ADMIN:NAV_LECT;
  let habN=0;if(S.me.role==='admin')progList().forEach(p=>{const ps=pStats(p.id);ps&&ps.active.forEach(s=>{if(ps.per[s.id].hab.stage>=2)habN++})});
  $('#side').innerHTML=`<div class="brand"><div class="brand-mark">AR</div><div><b>${esc(c.orgName)}</b><span>Attendance Register</span></div></div>
  <nav class="nav" aria-label="Main">${nav.map(n=>n[0]==='sep'?`<div class="navsep">${n[1]}</div>`:`<a href="#${n[0]}" class="${S.view===n[0]?'on':''}">${icon(n[2])}<span>${n[1]}</span>${n[0]==='absenteeism'&&habN?`<span class="cnt">${habN}</span>`:''}</a>`).join('')}</nav>
  <div class="who"><div class="whotext"><b>${esc(S.me.name||S.me.username)}</b><span class="tiny muted">${S.me.role==='admin'?'Administrator':'Lecturer'} · ${esc(S.me.username)}</span></div>
  <div class="row"><button class="btn sm" data-act="pw">Password</button><button class="btn sm ghost" data-act="logout">Sign out</button></div><span class="tiny muted" id="savedot" ${Store.pending?'':'hidden'}>Saving…</span></div>`;
}
function renderMain(fromData){
  if(!S.me||!$('#main'))return;
  const ae=document.activeElement;
  if(fromData&&ae&&$('#main').contains(ae)&&/INPUT|TEXTAREA/.test(ae.tagName)&&ae.type!=='checkbox')return; // don't clobber typing
  const sy=window.scrollY;const same=S.lastView===S.view;S.lastView=S.view;
  const keep={};if(same)document.querySelectorAll('[data-ks]').forEach(el=>keep[el.dataset.ks]=[el.scrollTop,el.scrollLeft]);
  if(fromData)renderShell();
  const views={overview:vOverview,attendance:vAttendance,calendar:vCalendar,programmes:vProgrammes,staff:vStaff,reports:vReports,absenteeism:vAbsenteeism,rules:vRules,data:vData,myclasses:vMyClasses};
  let banner='';
  if(!navigator.onLine)banner=`<div class="mode-banner">You are offline. Changes can’t be saved until the connection returns. Anything you have marked but not saved stays on this page, so keep it open.</div>`;
  $('#main').innerHTML=`<div class="wrap">${banner}${(views[S.view]||vOverview)()}</div>`;
  if(same)window.scrollTo(0,sy);else window.scrollTo(0,0);
  document.querySelectorAll('[data-ks]').forEach(el=>{const k=keep[el.dataset.ks];if(k){el.scrollTop=k[0];el.scrollLeft=k[1]}});
  afterRender();
}
let afterFns=[];function after(fn){afterFns.push(fn)}
function afterRender(){const f=afterFns;afterFns=[];f.forEach(x=>{try{x()}catch(e){console.error(e)}})}

/* ============ shared UI ============ */
function toast(msg,bad){const t=$('#toast');t.textContent=msg;t.className=bad?'bad':'';t.hidden=false;clearTimeout(t._t);t._t=setTimeout(()=>t.hidden=true,3600)}
function openModal(html,wide){const m=$('#modal');m.innerHTML=`<div class="mbox ${wide?'wide':''}" role="dialog" aria-modal="true">${html}</div>`;m.hidden=false;const f=m.querySelector('input:not([type=hidden]),select,textarea');if(f)setTimeout(()=>f.focus(),30)}
function closeModal(){const m=$('#modal');m.hidden=true;m.innerHTML=''}
function mhead(t,sub){return `<div class="mhead"><div><h2>${esc(t)}</h2>${sub?`<p class="muted small">${sub}</p>`:''}</div><button class="btn ghost sm" data-act="close" aria-label="Close">✕</button></div>`}
async function guard(fn,okMsg){try{await fn();if(okMsg)toast(okMsg)}catch(e){console.error(e);toast((e&&e.message)||'Could not save. Check your connection and try again.',true)}}
function progOptions(sel,list,allLabel){return (allLabel?`<option value="all" ${sel==='all'?'selected':''}>${allLabel}</option>`:'')+list.map(p=>`<option value="${p.id}" ${p.id===sel?'selected':''}>${esc(p.batch?p.batch+' · ':'')}${esc(p.name)}</option>`).join('')}
function pbar(v,st){const c=cfg();return `<div class="bar" title="${fmtPct(v)}"><i class="bg-${st}" style="width:${Math.max(0,Math.min(100,v||0))}%"></i><span class="thr" style="left:${c.threshold}%"></span></div>`}
function weekStrip(r,ps){const c=cfg();let h='';for(let w=1;w<=ps.weeksTotal;w++){const x=r.weeks[w];if(!x||!x.cond){h+=`<i class="bg-none" title="Week ${w}: no records"></i>`;continue}const v=x.att/x.cond*100;h+=`<i class="bg-${statusOf(v,null,c)}" title="Week ${w}: ${fmtPct(v)} (${x.att}/${x.cond})"></i>`}return `<div class="strip" aria-label="Weekly attendance">${h}</div>`}
function myAssign(pid){if(S.me.role==='admin')return range(1,(prog(pid)||{}).slots||6);const a=(S.me.assign||[]).find(x=>x.pid===pid);if(!a)return [];return a.slots&&a.slots.length?a.slots:range(1,(prog(pid)||{}).slots||6)}
function myProgs(){return progList().filter(p=>S.me.role==='admin'||myAssign(p.id).length)}
function slotRange(sl){if(!sl.length)return '';const s=sl.slice().sort((a,b)=>a-b);const out=[];let a=s[0],b=s[0];for(let i=1;i<=s.length;i++){if(s[i]===b+1){b=s[i]}else{out.push(a===b?a:a+'–'+b);a=b=s[i]}}return (s.length>1?'slots ':'slot ')+out.join(', ')}

/* ============ Overview ============ */
function vOverview(){
  const c=cfg();const today=D.today();const P=progList();
  if(!P.length)return `<div class="pagehead"><div><h1>Overview</h1><p>No programmes yet. Create a programme or import an existing Excel attendance sheet to get started.</p></div></div>
    <div class="panel"><div class="row"><button class="btn pri" data-go="programmes">Create a programme</button><button class="btn" data-go="data">Import Excel sheet</button></div></div>`;
  let A=0,C=0,stu=0,below=0,hab=0,miss=0;const rows=[],alerts=[],todays=[];
  for(const p of P){const ps=pStats(p.id);if(!ps)continue;
    ps.active.forEach(s=>{const r=ps.per[s.id];A+=r.att;C+=r.cond;stu++;if(r.status==='below'||r.status==='critical')below++;if(r.hab.stage>=2)hab++;if(r.status!=='good'&&r.status!=='none'||r.hab.stage>=2)alerts.push({p,s,r})});
    miss+=ps.missing;
    const td=ps.days.find(d=>d.date===today);if(td)todays.push({p,d:td});
    rows.push({p,ps});
  }
  alerts.sort((a,b)=>b.r.hab.score-a.r.hab.score||(a.r.pct??0)-(b.r.pct??0));
  const k=(v,l,s,cls)=>`<div class="kpi ${cls||''}"><span class="l">${l}</span><span class="v">${v}</span><span class="s">${s}</span></div>`;
  return `<div class="pagehead"><div><span class="eyebrow">${D.long(today)}</span><h1>Overview</h1><p>Attendance across all active programmes. Percentages count only lecture slots that have been held and marked.</p></div>
    <div class="row"><button class="btn" data-go="reports">Open register</button><button class="btn pri" data-go="attendance">Take attendance</button></div></div>
  <div class="kpis">${k(fmtPct(C?A/C*100:null),'Attendance to date',`${A.toLocaleString()} of ${C.toLocaleString()} student-slots`)}
    ${k(stu,'Students',`${P.length} active programme${P.length!==1?'s':''}`)}
    ${k(below,`Below ${c.threshold}%`,'students under the minimum to date',below?'alert':'')}
    ${k(hab,'Habitual absence','Stage 2 and Stage 3 cases',hab?'alert':'')}
    ${k(miss,'Unmarked slots','held lecture slots with no attendance',miss?'alert':'')}</div>
  <div class="cols"><div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>Programmes</h2><span class="tiny muted">Bar marker = ${c.threshold}% minimum</span></div>
    <div class="tbl-wrap"><table class="t"><thead><tr><th>Programme</th><th>Week</th><th class="r">Avg to date</th><th style="min-width:120px">Students by status</th><th></th></tr></thead><tbody>
    ${rows.map(({p,ps})=>`<tr class="click" data-act="openreg" data-pid="${p.id}"><td><b>${esc(p.name)}</b><div class="tiny muted">${esc(p.batch||'')} · ${ps.active.length} students</div></td>
      <td class="num">${ps.curWk?`W${pad(ps.curWk)}`:'–'}<span class="muted"> / ${ps.weeksTotal}</span></td>
      <td class="r num"><b>${fmtPct(ps.avg)}</b>${pbar(ps.avg,statusOf(ps.avg,null,c))}</td>
      <td>${distBar(ps.dist)}</td><td class="r"><span class="tiny muted">Register ›</span></td></tr>`).join('')}
    </tbody></table></div></div>
    <div class="panel"><div class="panel-h"><h2>Today</h2><span class="tiny muted">${D.nice(today)}</span></div>
      ${todays.length?todays.map(({p,d})=>`<button class="tc" data-act="gomark" data-pid="${p.id}" data-date="${d.date}"><b>${esc(p.name)}</b><span class="tiny muted">${esc(p.batch||'')} · W${pad(d.wk)}${d.note?' · '+esc(d.note):''}</span>
        <div class="slotdots">${d.slots.map(s=>`<i class="${d.conducted.includes(s)?'ok':'miss'}" title="Slot ${s}: ${d.conducted.includes(s)?'marked':'not marked yet'}">${s}</i>`).join('')}</div></button>`).join(''):`<p class="muted small">No academic sessions are scheduled today.</p>`}
    </div></div>
  <div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>Students needing attention</h2><button class="btn sm" data-go="absenteeism">Habitual absenteeism report</button></div>
    ${alerts.length?`<div class="tbl-wrap"><table class="t"><thead><tr><th>Student</th><th>Programme</th><th class="r">To date</th><th class="r">Best possible</th><th>Status</th><th>Absence stage</th></tr></thead><tbody>
    ${alerts.slice(0,12).map(({p,s,r})=>`<tr class="click" data-act="student" data-sid="${s.id}"><td><b>${esc(sName(s))}</b></td><td class="small">${esc(p.name)}</td><td class="r num">${fmtPct(r.pct)}</td><td class="r num">${fmtPct(r.maxPct)}</td><td>${pill(r.status)}</td><td>${stagePill(r.hab.stage)||'<span class="muted tiny">–</span>'}</td></tr>`).join('')}
    </tbody></table></div>${alerts.length>12?`<p class="tiny muted" style="padding:0 18px 14px">Showing 12 of ${alerts.length}. See the habitual absenteeism report for the full list.</p>`:''}`:`<div class="empty">Every student is on track.</div>`}
  </div>`;
}
function distBar(d){const t=Object.values(d).reduce((a,b)=>a+b,0)||1;const parts=['good','watch','below','critical'].filter(k=>d[k]);
  return `<div class="dist" title="${parts.map(k=>STL[k]+': '+d[k]).join(' · ')}">${parts.map(k=>`<i class="bg-${k}" style="width:${d[k]/t*100}%"></i>`).join('')}${d.none?`<i class="bg-none" style="width:${d.none/t*100}%"></i>`:''}</div>
  <div class="tiny muted" style="margin-top:4px">${parts.map(k=>`${d[k]} ${k==='good'?'on track':k==='watch'?'watch':k==='below'?'below':'critical'}`).join(' · ')||'no records'}</div>`}

/* ============ Take attendance ============ */
function pickDefaultDay(p){const ds=progDays(p);const t=D.today();let d=ds.find(x=>x.date===t);if(d)return d.date;const past=ds.filter(x=>x.date<=t);return past.length?past[past.length-1].date:(ds[0]||{}).date}
function vAttendance(){
  const P=myProgs();
  if(!P.length)return `<div class="pagehead"><div><h1>Take attendance</h1><p>${S.me.role==='admin'?'There are no active programmes yet.':'No classes are assigned to you yet. Ask an administrator to assign your programmes and lecture slots.'}</p></div></div>`;
  const today=D.today();
  if(!S.mk.pid||!P.find(p=>p.id===S.mk.pid)){S.mk.pid=(P.find(p=>progDays(p).some(d=>d.date===today))||P[0]).id;S.mk.date=null}
  const p=prog(S.mk.pid);const days=progDays(p);
  if(!S.mk.date||!days.find(d=>d.date===S.mk.date))S.mk.date=pickDefaultDay(p);
  const day=days.find(d=>d.date===S.mk.date);
  const ps=pStats(p.id);const studs=studentsOf(p.id,false);
  const mine=myAssign(p.id);const slots=day?day.slots.filter(s=>mine.includes(s)):[];
  const rule=markRule(p,day);const key=p.id+'|'+S.mk.date;
  const doc=DATA.att[p.id+'__'+S.mk.date]||{};const saved=doc.marks||{};
  if(!S.draft||S.draft.key!==key){S.draft={key,marks:clone(saved),dirty:false}}
  else if(!S.draft.dirty){S.draft.marks=clone(saved)}
  const dm=S.draft.marks;const c=cfg();
  const todays=P.map(x=>({p:x,d:progDays(x).find(d=>d.date===today)})).filter(x=>x.d);
  const dayOpts=days.map(d=>`<option value="${d.date}" ${d.date===S.mk.date?'selected':''} ${d.date>today?'disabled':''}>W${pad(d.wk)} · ${D.nice(d.date)}${d.date===today?' (today)':''}${d.date>today?' · upcoming':''}${d.lock==='locked'?' · locked':''}</option>`).join('');
  const cnt=sl=>{const m=dm[sl]||{};let P_=0,A_=0,L_=0,E_=0,U=0;studs.forEach(s=>{const v=m[s.id]||'';if(v==='P')P_++;else if(v==='A')A_++;else if(v==='L')L_++;else if(v==='E')E_++;else U++});return {P:P_,A:A_,L:L_,E:E_,U}};
  const changes=S.draft.dirty?slots.reduce((a,sl)=>a+studs.filter(s=>((dm[sl]||{})[s.id]||'')!==((saved[sl]||{})[s.id]||'')).length,0):0;
  const metaLine=slots.map(sl=>doc.meta&&doc.meta[sl]?`Slot ${sl}: ${esc(doc.meta[sl].name||'')} · ${new Date(doc.meta[sl].at).toLocaleString([], {day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}`:'').filter(Boolean).join(' &nbsp;·&nbsp; ');
  return `<div class="pagehead"><div><h1>Take attendance</h1><p>Tap a box to mark it. Each tap moves through Present, Absent, Late and Excused. Use “Mark all present” first, then tap only the students who are missing.</p></div></div>
  ${todays.length>0?`<div class="todaycards">${todays.map(({p:x,d})=>{const st=pStats(x.id).days.find(z=>z.date===d.date);const my=d.slots.filter(s=>myAssign(x.id).includes(s));return `<button class="tc ${x.id===p.id&&d.date===S.mk.date?'on':''}" data-act="gomark" data-pid="${x.id}" data-date="${d.date}"><span class="eyebrow">Today · W${pad(d.wk)}</span><b>${esc(x.name)}</b><span class="tiny muted">${esc(x.batch||'')} · your ${slotRange(my)}</span><div class="slotdots">${my.map(s=>`<i class="${st&&st.conducted.includes(s)?'ok':''}">${s}</i>`).join('')}</div></button>`}).join('')}</div>`:''}
  <div class="panel">
    <div class="toolbar"><div class="field"><label for="mk-pid">Programme</label><select id="mk-pid" data-chg="mkpid">${progOptions(p.id,P)}</select></div>
    <div class="field"><label for="mk-date">Academic day</label><select id="mk-date" data-chg="mkdate">${dayOpts}</select></div>
    <div class="spacer"></div>
    <div class="legend"><span><b class="mk P" style="width:22px;height:20px">P</b>Present</span><span><b class="mk A" style="width:22px;height:20px">A</b>Absent</span><span><b class="mk L" style="width:22px;height:20px">L</b>Late${c.lateCounts?' (counts as present)':''}</span><span><b class="mk E" style="width:22px;height:20px">E</b>Excused${c.excusedCounts?' (counts as present)':' (counts as absent)'}</span></div></div>
    ${day?.note?`<div class="notice info">Note for this day: ${esc(day.note)}</div>`:''}
    ${!rule.ok?`<div class="notice warn">${esc(rule.why)} The sheet below is read-only.</div>`:rule.why?`<div class="notice info">${esc(rule.why)}</div>`:''}
    ${!slots.length?`<div class="notice warn">None of your assigned lecture slots run on this day.</div>`:''}
    ${!studs.length?`<div class="notice warn">This programme has no students yet.${S.me.role==='admin'?' Add students under Programmes & students.':''}</div>`:''}
    ${slots.length&&studs.length&&rule.ok?`<div class="row"><button class="btn" data-act="allp">Mark all present</button><span class="tiny muted">Fills empty boxes in your ${slotRange(slots)} with P. Boxes already marked stay as they are.</span></div>`:''}
  </div>
  ${slots.length&&studs.length?`<div class="panel flush"><div class="sheet-wrap" data-ks="sheet"><table class="sheet"><thead><tr><th class="nm">Student</th>
    ${slots.map(sl=>`<th><div>Slot ${sl}</div><div class="tiny muted">${sessionOf(p,sl)}</div>${rule.ok?`<button class="btn sm ghost" data-act="colp" data-slot="${sl}" title="Mark everyone present in slot ${sl}">All P</button>`:''}</th>`).join('')}
    <th>To date</th></tr></thead><tbody>
    ${studs.map(s=>{const r=ps.per[s.id];return `<tr><td class="nm"><span class="muted tiny mono">${pad(s.no||0)}</span> <b>${esc(s.first)}</b> ${esc(s.last)}</td>
      ${slots.map(sl=>{const v=(dm[sl]||{})[s.id]||'';const ch=v!==((saved[sl]||{})[s.id]||'');return `<td class="c"><button class="mk ${v} ${rule.ok?'':'ro'} ${ch?'chg':''}" data-act="cyc" data-sid="${s.id}" data-slot="${sl}" ${rule.ok?'':'disabled'} aria-label="${esc(sName(s))}, slot ${sl}: ${v||'not marked'}">${v||'·'}</button></td>`}).join('')}
      <td class="c">${pill(r?r.status:'none',fmtPct(r&&r.pct))}</td></tr>`}).join('')}
    </tbody><tfoot><tr><td class="nm"><b>Totals</b></td>${slots.map(sl=>{const k=cnt(sl);return `<td><span title="Present">${k.P+k.L}✓</span> <span title="Absent" style="color:var(--crit)">${k.A}✗</span>${k.U?` <span class="muted" title="Not marked">${k.U}?</span>`:''}</td>`}).join('')}<td></td></tr></tfoot></table></div></div>
  ${metaLine?`<p class="tiny muted">Last saved — ${metaLine}</p>`:''}
  ${rule.ok?`<div class="savebar ${S.draft.dirty?'dirty':''}"><span>${S.draft.dirty?`<b>${changes}</b> unsaved change${changes!==1?'s':''}`:'All changes saved'}</span><span class="spacer"></span>
    <button class="btn ghost" data-act="discard" ${S.draft.dirty?'':'disabled'}>Discard</button><button class="btn pri" data-act="savemk" ${S.draft.dirty?'':'disabled'}>Save attendance</button></div>`:''}`:''}`;
}
const CYCLE={'':'P','P':'A','A':'L','L':'E','E':''};
async function saveMarks(){
  const p=prog(S.mk.pid);const day=progDays(p).find(d=>d.date===S.mk.date);const rule=markRule(p,day);if(!rule.ok){toast(rule.why,true);return}
  const slots=day.slots.filter(s=>myAssign(p.id).includes(s));const studs=studentsOf(p.id,false);
  const marks={},meta={};const at=new Date().toISOString();
  const doc=DATA.att[p.id+'__'+S.mk.date]||{};const saved=doc.marks||{};
  for(const sl of slots){const m=S.draft.marks[sl]||{};const o={};let ch=false;studs.forEach(s=>{const v=m[s.id]||'';o[s.id]=v;if(v!==((saved[sl]||{})[s.id]||''))ch=true});if(ch){marks[sl]=o;meta[sl]={by:S.me.id,name:S.me.name||S.me.username,at}}}
  if(!Object.keys(marks).length){S.draft.dirty=false;renderMain();return}
  const unm=Object.values(marks).reduce((a,o)=>a+Object.values(o).filter(v=>!v).length,0);
  await guard(async()=>{await Store.merge('att/'+p.id+'__'+S.mk.date,{pid:p.id,date:S.mk.date,marks,meta});S.draft.dirty=false;S.draft.marks=clone((DATA.att[p.id+'__'+S.mk.date]||{}).marks||S.draft.marks);renderMain();
    toast(`Saved ${slotRange(Object.keys(marks).map(Number))} for ${D.nice(S.mk.date)}.${unm?` ${unm} box${unm>1?'es are':' is'} still unmarked.`:''}`)});
}

/* ============ Calendar ============ */
function vCalendar(){
  const P=progList();if(!P.length)return `<div class="pagehead"><div><h1>Academic calendar</h1><p>Create a programme first.</p></div></div>`;
  if(!S.cal.pid||!prog(S.cal.pid))S.cal.pid=P[0].id;
  const p=prog(S.cal.pid);
  if(!S.cal.month){const t=D.today();S.cal.month=(t>=p.start&&t<=(p.end||t))?D.month(t):D.month(p.start)}
  const [y,m]=S.cal.month.split('-').map(Number);const first=`${y}-${pad(m)}-01`;const dim=new Date(Date.UTC(y,m,0)).getUTCDate();
  const lead=(D.dow(first)+6)%7;const today=D.today();const ps=pStats(p.id);
  const daysInfo=Object.fromEntries(ps.days.map(d=>[d.date,d]));
  let cells='';for(let i=0;i<lead;i++)cells+=`<div class="cd blank" aria-hidden="true"></div>`;
  for(let d=1;d<=dim;d++){const ds=`${y}-${pad(m)}-${pad(d)}`;const st=dayState(p,ds);const di=daysInfo[ds];
    const cls=['cd',st.st,ds===today?'today':'',S.cal.sel.has(ds)?'sel':'',!st.inRange&&st.st==='off'?'out':''].join(' ');
    const tag=st.st==='acad'?`W${pad(di?di.wk:0)}`:st.st==='extra'?'Make-up':st.st==='blocked'?'Blocked':'';
    const lk=st.lock==='locked'?'LOCKED':st.lock==='open'?'OPEN':'';
    const mkd=di&&ds<=today?`<span class="tiny mkd ${di.missing.length?'':'muted'}" style="${di.missing.length?'color:var(--crit)':''}">${di.conducted.length}/${di.slots.length} marked</span>`:'';
    const slotsNote=di&&di.slots.length<p.slots?`<span class="nt">${slotRange(di.slots)}</span>`:'';
    cells+=`<button class="${cls}" data-act="calsel" data-date="${ds}" aria-pressed="${S.cal.sel.has(ds)}" aria-label="${D.long(ds)} ${tag}"><span class="dn">${d}</span>${tag?`<span class="tg">${tag}</span>`:''}${lk?`<span class="lk">${lk}</span>`:''}${mkd}${slotsNote}${st.note?`<span class="nt" title="${esc(st.note)}">${esc(st.note)}</span>`:''}</button>`;
  }
  const prev=D.month(D.add(first,-1)),next=D.month(D.add(first,dim));
  const short=ps.target-ps.planned;const sel=[...S.cal.sel].sort();
  const blockedAll=Object.entries((DATA.calendar[p.id]||{}).days||{}).filter(([,v])=>v.state==='blocked').map(([d,v])=>({d,...v})).sort((a,b)=>a.d.localeCompare(b.d));
  const extrasAll=ps.days.filter(d=>d.extra);
  return `<div class="pagehead"><div><h1>Academic calendar</h1><p>Choose which days run as academic days. Block holidays and closures, add make-up days, change which lecture slots run, and lock days so lecturers can no longer edit them.</p></div></div>
  <div class="panel"><div class="calbar"><div class="field" style="min-width:220px;flex:0 1 300px"><label for="cal-pid">Programme</label><select id="cal-pid" data-chg="calpid">${progOptions(p.id,P)}</select></div>
    <div class="spacer"></div><div class="row"><button class="btn sm" data-act="calmonth" data-m="${prev}" aria-label="Previous month">‹</button><b style="min-width:140px;text-align:center;font-family:var(--f-display);font-size:1.1rem">${D.monthName(S.cal.month)}</b><button class="btn sm" data-act="calmonth" data-m="${next}" aria-label="Next month">›</button></div></div>
    <div class="row small"><span class="chip tag-acc">Wnn = academic day</span><span class="chip" style="background:var(--exc-soft);color:var(--exc);border-color:transparent">Make-up day</span><span class="chip" style="background:var(--crit-soft);color:var(--crit);border-color:transparent">Blocked</span><span class="chip">LOCKED / OPEN = marking override</span><span class="muted tiny">Click days to select them, then choose an action.</span></div>
    <div class="cal">${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<div class="dh">${x}</div>`).join('')}${cells}</div>
    <div class="row"><button class="btn sm" data-act="calselacad">Select all academic days this month</button>${sel.length?`<button class="btn sm ghost" data-act="calclear">Clear selection (${sel.length})</button>`:''}</div>
  </div>
  ${sel.length?`<div class="panel" style="border-color:var(--accent)"><div class="panel-h"><h2>${sel.length} day${sel.length>1?'s':''} selected</h2><span class="tiny muted">${sel.slice(0,6).map(D.short).join(', ')}${sel.length>6?'…':''}</span></div>
    <div class="grid2"><div class="field"><label for="cal-note">Reason or note (shown to lecturers)</label><input type="text" id="cal-note" placeholder="e.g. Poya holiday, field visit, make-up for 26 Oct"></div>
    <div class="field"><span class="lbl">Lecture slots that run on these days</span><div class="slotpick">${range(1,p.slots).map(s=>`<label><input type="checkbox" class="cal-slot" value="${s}" checked> ${s} <span class="tiny muted">${sessionOf(p,s).slice(0,3)}</span></label>`).join('')}</div></div></div>
    <label class="check"><input type="checkbox" id="cal-all"> Apply to all ${progList().length} active programmes (for institute-wide holidays)</label>
    <div class="row"><button class="btn danger" data-act="calapply" data-op="block">Block days</button><button class="btn pri" data-act="calapply" data-op="enable">Enable as academic day</button><button class="btn" data-act="calapply" data-op="slots">Save running slots</button><button class="btn" data-act="calapply" data-op="lock">Lock marking</button><button class="btn" data-act="calapply" data-op="open">Reopen marking</button><button class="btn ghost" data-act="calapply" data-op="reset">Restore default</button></div>
    <p class="tiny muted">“Lock marking” stops lecturers editing those days. “Reopen marking” lets lecturers edit a past day after the ${cfg().editWindow}-day window. “Restore default” returns the days to the regular timetable.</p></div>`:''}
  <div class="grid2"><div class="panel"><h2>Programme plan</h2>
    <div class="kpis" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="kpi"><span class="l">Planned academic days</span><span class="v">${ps.days.length}</span><span class="s">target ${(p.weeks||0)*(p.weekdays||[]).length} (${p.weeks} weeks × ${(p.weekdays||[]).length} days)</span></div>
    <div class="kpi ${short>0?'alert':''}"><span class="l">Planned lecture slots</span><span class="v">${ps.planned}</span><span class="s">target ${ps.target}</span></div></div>
    ${short>0?`<div class="notice warn">The plan is ${short} slot${short>1?'s':''} short of the ${ps.target}-slot programme. Add make-up days or extend the end date. Final percentages use the ${ps.planned} planned slots.</div>`:short<0?`<div class="notice info">The plan has ${-short} more slots than the target of ${ps.target}.</div>`:`<div class="notice info">The plan matches the ${ps.target}-slot programme.</div>`}
    <p class="small ink2">Runs ${D.long(p.start)} to ${D.long(p.end)} on ${(p.weekdays||[]).map(w=>DOW[w]).join(' & ')}. Lecturers can edit a day for ${cfg().editWindow} days after it, unless it's locked or reopened.</p></div>
  <div class="panel"><h2>Changes to the regular timetable</h2>
    ${blockedAll.length||extrasAll.length?`<div class="tbl-wrap"><table class="t"><tbody>${blockedAll.map(b=>`<tr><td class="num">${D.nice(b.d)} ${b.d.slice(0,4)}</td><td><span class="pill st-critical">Blocked</span></td><td class="small">${esc(b.note||'')}</td></tr>`).join('')}${extrasAll.map(b=>`<tr><td class="num">${D.nice(b.date)} ${b.date.slice(0,4)}</td><td><span class="pill" style="background:var(--exc-soft);color:var(--exc)">Make-up</span></td><td class="small">${esc(b.note||'')}</td></tr>`).join('')}</tbody></table></div>`:`<p class="muted small">No blocked or make-up days yet.</p>`}</div></div>`;
}
async function calApply(op){
  const sel=[...S.cal.sel];if(!sel.length)return;
  const note=($('#cal-note')||{}).value||'';const slots=[...document.querySelectorAll('.cal-slot:checked')].map(x=>+x.value);
  const all=$('#cal-all')&&$('#cal-all').checked;const pids=all?progList().map(p=>p.id):[S.cal.pid];
  let n=0,skipped=0,withMarks=0;
  await guard(async()=>{
    for(const pid of pids){const p=prog(pid);const days={};
      for(const d of sel){const st=dayState(p,d);let v=null;
        if(op==='block'){if(st.sched){v={state:'blocked'};if(note)v.note=note;if(DATA.att[pid+'__'+d])withMarks++}else if(st.st==='extra'){v={state:'',note:''}}else skipped++}
        else if(op==='enable'){v={state:st.sched?'':'extra'};if(note)v.note=note;else if(st.st==='blocked')v.note=''}
        else if(op==='slots'){if(!slots.length){toast('Pick at least one lecture slot.',true);return}v={slots:slots.length===p.slots?[]:slots};if(note)v.note=note}
        else if(op==='lock')v={lock:'locked'};else if(op==='open')v={lock:'open'};
        else if(op==='reset')v={state:'',lock:'',note:'',slots:[]};
        if(v){days[d]=v;n++}}
      if(Object.keys(days).length)await Store.merge('calendar/'+pid,{pid,days});
    }
    S.cal.sel.clear();renderMain();
    const lbl={block:'Blocked',enable:'Enabled',slots:'Updated slots for',lock:'Locked',open:'Reopened',reset:'Restored'}[op];
    toast(`${lbl} ${n} day${n!==1?'s':''}${pids.length>1?` across ${pids.length} programmes`:''}.${withMarks?` ${withMarks} of them already had marks; those marks no longer count.`:''}${skipped?` ${skipped} non-timetabled day${skipped>1?'s were':' was'} skipped.`:''}`);
  });
}

/* ============ Programmes & students ============ */
function vProgrammes(){
  const all=progList(true);
  if(S.prog.stu&&prog(S.prog.stu))return vStudents(prog(S.prog.stu));
  const card=p=>{const ps=pStats(p.id);const n=studentsOf(p.id,false).length;return `<tr><td><b>${esc(p.name)}</b><div class="tiny muted">${esc(p.batch||'')}${p.level?' · '+esc(p.level):''}</div></td>
    <td class="small num">${D.short(p.start)} – ${D.long(p.end)}<div class="tiny muted">${(p.weekdays||[]).map(w=>DOW[w]).join(', ')} · ${p.slots} slots/day · ${p.weeks} weeks</div></td>
    <td class="num">${n}</td><td class="num">${ps?ps.planned:0}<span class="muted">/${ps?ps.target:0}</span></td><td class="num">${ps?fmtPct(ps.avg):'–'}</td>
    <td class="r"><div class="row end"><button class="btn sm" data-act="stu" data-pid="${p.id}">Students</button><button class="btn sm" data-act="progedit" data-pid="${p.id}">Edit</button><button class="btn sm ghost" data-act="progdup" data-pid="${p.id}">New batch</button></div></td></tr>`};
  const act=all.filter(p=>p.status!=='archived'),arc=all.filter(p=>p.status==='archived');
  const tbl=list=>`<div class="tbl-wrap"><table class="t"><thead><tr><th>Programme</th><th>Schedule</th><th>Students</th><th>Planned slots</th><th>Avg</th><th></th></tr></thead><tbody>${list.map(card).join('')}</tbody></table></div>`;
  return `<div class="pagehead"><div><h1>Programmes & students</h1><p>Each programme is one class group in a batch. Use “New batch” to start the next intake with the same structure.</p></div>
    <div class="row"><button class="btn" data-go="data">Import Excel sheet</button><button class="btn pri" data-act="progedit">New programme</button></div></div>
  <div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>Active</h2></div>${act.length?tbl(act):'<div class="empty">No active programmes.</div>'}</div>
  ${arc.length?`<div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>Archived</h2><span class="tiny muted">Archived batches stay available in reports.</span></div>${tbl(arc)}</div>`:''}`;
}
function progModal(pid,dup){
  const p=pid?prog(pid):null;const src=p||{name:'',batch:'',level:'Foundation',start:D.today(),weekdays:[2,3],weeks:24,slots:6,split:3,status:'active'};
  const v={...src};if(dup){v.batch='';v.start='';v.status='active'}
  const lvls=['Foundation','Intermediate','Advance','Diploma','Other'];
  openModal(`${mhead(dup?'Start a new batch':p?'Edit programme':'New programme',dup?`Copies the structure of ${esc(p.name)}. Students are added separately.`:'Totals and percentages follow these settings.')}
  <form id="progForm"><div class="mbody">
    <div class="grid2"><div class="field"><label for="pf-name">Programme name</label><input type="text" id="pf-name" required value="${esc(v.name)}" placeholder="Foundation – Culinary"></div>
    <div class="field"><label for="pf-batch">Batch</label><input type="text" id="pf-batch" required value="${esc(v.batch)}" placeholder="Batch 06"></div></div>
    <div class="grid3"><div class="field"><label for="pf-level">Level</label><select id="pf-level">${lvls.map(l=>`<option ${l===v.level?'selected':''}>${l}</option>`).join('')}</select></div>
    <div class="field"><label for="pf-start">First academic day</label><input type="date" id="pf-start" required value="${esc(v.start)}"></div>
    <div class="field"><label for="pf-status">Status</label><select id="pf-status"><option value="active" ${v.status!=='archived'?'selected':''}>Active</option><option value="archived" ${v.status==='archived'?'selected':''}>Archived</option></select></div></div>
    <div class="field"><span class="lbl">Academic days each week</span><div class="slotpick">${[1,2,3,4,5,6].map(w=>`<label><input type="checkbox" class="pf-wd" value="${w}" ${(v.weekdays||[]).includes(w)?'checked':''}> ${DOW[w]}</label>`).join('')}</div></div>
    <div class="grid3"><div class="field"><label for="pf-weeks">Academic weeks</label><input type="number" id="pf-weeks" min="1" max="60" value="${v.weeks}"></div>
    <div class="field"><label for="pf-slots">Lecture slots per day</label><input type="number" id="pf-slots" min="1" max="12" value="${v.slots}"></div>
    <div class="field"><label for="pf-split">Morning slots</label><input type="number" id="pf-split" min="0" max="12" value="${v.split??3}"><span class="hint">Slots after these count as Evening.</span></div></div>
    <div class="notice info" id="pf-total"></div>
    ${p&&!dup?`<p class="tiny muted">Changing the start date, days or weeks moves the academic days. Attendance already saved stays on its original date.</p>`:''}
  </div><div class="mfoot">${p&&!dup?`<button type="button" class="btn danger" data-act="progdel" data-pid="${p.id}" style="margin-right:auto">Delete…</button>`:''}<button type="button" class="btn" data-act="close">Cancel</button><button class="btn pri" type="submit">${dup?'Create batch':p?'Save changes':'Create programme'}</button></div></form>`);
  const upd=()=>{const wd=document.querySelectorAll('.pf-wd:checked').length,w=+$('#pf-weeks').value||0,s=+$('#pf-slots').value||0;const st=$('#pf-start').value;
    $('#pf-total').textContent=`${w} weeks × ${wd} days × ${s} slots = ${w*wd*s} lecture slots per programme.${st?` Runs to ${D.long(D.add(D.monday(st),w*7-1))}.`:''}`};
  upd();$('#progForm').addEventListener('input',upd);
  $('#progForm').addEventListener('submit',async e=>{e.preventDefault();
    const wd=[...document.querySelectorAll('.pf-wd:checked')].map(x=>+x.value);if(!wd.length){toast('Choose at least one academic day.',true);return}
    const start=$('#pf-start').value,weeks=+$('#pf-weeks').value,slots=+$('#pf-slots').value;
    const data={...(p&&!dup?DATA.programmes[pid]:{}),name:$('#pf-name').value.trim(),batch:$('#pf-batch').value.trim(),level:$('#pf-level').value,start,weeks,slots,split:Math.min(+$('#pf-split').value,slots),weekdays:wd.sort(),status:$('#pf-status').value,end:D.add(D.monday(start),weeks*7-1)};
    if(!p||dup){data.created=new Date().toISOString();data.order=(src.order||9)}
    const id=p&&!dup?pid:'p-'+uid('').slice(1,10);
    await guard(async()=>{await Store.set('programmes/'+id,data);closeModal();renderMain()},p&&!dup?'Programme saved.':'Programme created. Add its students next.');
  });
}
function vStudents(p){
  const studs=studentsOf(p.id,true);const ps=pStats(p.id);
  return `<div class="pagehead"><div><button class="btn sm ghost" data-act="stuback">‹ All programmes</button><h1>${esc(p.name)}</h1><p>${esc(p.batch||'')} · ${studs.filter(s=>s.status!=='withdrawn').length} active students. Withdrawn students drop out of marking sheets and class averages but keep their history.</p></div>
    <div class="row"><button class="btn" data-act="stubulk" data-pid="${p.id}">Paste a list</button><button class="btn pri" data-act="stuedit" data-pid="${p.id}">Add student</button></div></div>
  <div class="panel flush">${studs.length?`<div class="tbl-wrap"><table class="t"><thead><tr><th>No.</th><th>First name</th><th>Last name</th><th>Student ID</th><th>Status</th><th class="r">To date</th><th></th></tr></thead><tbody>
  ${studs.map(s=>{const r=ps.per[s.id];return `<tr class="${s.status==='withdrawn'?'withdrawn':''}"><td class="num mono">${pad(s.no||0)}</td><td><b>${esc(s.first)}</b></td><td>${esc(s.last)}</td><td class="mono">${esc(s.reg||'–')}</td><td>${s.status==='withdrawn'?'<span class="pill st-none">Withdrawn</span>':'<span class="pill st-good">Active</span>'}</td><td class="r num">${fmtPct(r&&r.pct)}</td>
  <td class="r"><div class="row end"><button class="btn sm ghost" data-act="student" data-sid="${s.id}">Profile</button><button class="btn sm" data-act="stuedit" data-pid="${p.id}" data-sid="${s.id}">Edit</button></div></td></tr>`}).join('')}</tbody></table></div>`:`<div class="empty">No students yet. Add them one at a time or paste a list from Excel.</div>`}</div>`;
}
function stuModal(pid,sid){
  const s=sid?{...DATA.students[sid],id:sid}:null;
  const next=Math.max(0,...studentsOf(pid,true).map(x=>x.no||0))+1;
  openModal(`${mhead(s?'Edit student':'Add student',esc(prog(pid).name))}<form id="stuForm"><div class="mbody">
    <div class="grid2"><div class="field"><label for="sf-first">First name</label><input type="text" id="sf-first" required value="${esc(s?.first)}"></div><div class="field"><label for="sf-last">Last name</label><input type="text" id="sf-last" value="${esc(s?.last)}"></div></div>
    <div class="grid3"><div class="field"><label for="sf-no">Register no.</label><input type="number" id="sf-no" min="1" value="${s?s.no:next}"></div><div class="field"><label for="sf-reg">Student ID</label><input type="text" id="sf-reg" value="${esc(s?.reg)}"></div>
    <div class="field"><label for="sf-status">Status</label><select id="sf-status"><option value="active">Active</option><option value="withdrawn" ${s?.status==='withdrawn'?'selected':''}>Withdrawn</option></select></div></div>
  </div><div class="mfoot">${s?`<button type="button" class="btn danger" data-act="studel" data-sid="${sid}" style="margin-right:auto">Delete…</button>`:''}<button type="button" class="btn" data-act="close">Cancel</button><button class="btn pri" type="submit">${s?'Save':'Add student'}</button></div></form>`);
  $('#stuForm').addEventListener('submit',async e=>{e.preventDefault();
    const data={pid,no:+$('#sf-no').value||next,first:$('#sf-first').value.trim(),last:$('#sf-last').value.trim(),reg:$('#sf-reg').value.trim(),status:$('#sf-status').value};
    await guard(async()=>{await Store.set('students/'+(sid||pid+'-'+uid('s').slice(2,9)),data);closeModal();renderMain()},s?'Student saved.':'Student added.')});
}
function bulkModal(pid){
  openModal(`${mhead('Paste a student list',esc(prog(pid).name))}<div class="mbody">
    <p class="small ink2">One student per line: <span class="mono">First name, Last name, Student ID</span>. Columns copied straight from Excel (tab-separated) work too. Student ID is optional.</p>
    <div class="field"><label for="bk-text">Students</label><textarea id="bk-text" placeholder="Abdeen	Aadhil	EHL-0501&#10;Shihara	Rahamath"></textarea></div><div class="tiny muted" id="bk-prev">0 students</div></div>
    <div class="mfoot"><button class="btn" data-act="close">Cancel</button><button class="btn pri" data-act="bulkgo" data-pid="${pid}">Add students</button></div>`);
  $('#bk-text').addEventListener('input',()=>{$('#bk-prev').textContent=parseBulk().length+' students'});
}
function parseBulk(){return ($('#bk-text').value||'').split(/\r?\n/).map(l=>l.split(/\t|,/).map(x=>x.trim())).filter(a=>a[0]).map(a=>({first:a[0],last:a[1]||'',reg:a[2]||''}))}

/* ============ Staff ============ */
function vStaff(){
  const U=Object.entries(DATA.users).map(([id,u])=>({id,...u})).sort((a,b)=>(a.role===b.role?0:a.role==='admin'?-1:1)||(a.name||'').localeCompare(b.name||''));
  return `<div class="pagehead"><div><h1>Lecturers & access</h1><p>Each person signs in with their email address and a password. Lecturers see only the programmes and lecture slots assigned here.</p></div><button class="btn pri" data-act="useredit">Add lecturer</button></div>
  <div class="panel flush"><div class="tbl-wrap"><table class="t"><thead><tr><th>Name</th><th>Email (sign-in)</th><th>Role</th><th>Assigned classes</th><th>Status</th><th></th></tr></thead><tbody>
  ${U.map(u=>`<tr class="${u.active===false?'withdrawn':''}"><td><b>${esc(u.name)}</b>${u.id===S.me.id?' <span class="tiny muted">(you)</span>':''}</td><td class="mono">${esc(u.email||u.id)}</td><td>${u.role==='admin'?'<span class="chip tag-acc">Administrator</span>':'Lecturer'}</td>
   <td>${u.role==='admin'?'<span class="tiny muted">All programmes</span>':`<div class="chips">${(u.assign||[]).filter(a=>prog(a.pid)).map(a=>{const p=prog(a.pid);return `<span class="chip">${esc(p.name)}${p.batch?` <span class="muted">${esc(p.batch)}</span>`:''} · ${a.slots&&a.slots.length?slotRange(a.slots):'all slots'}</span>`}).join('')||'<span class="tiny muted">Nothing assigned</span>'}</div>`}</td>
   <td>${u.active===false?'<span class="pill st-none">Disabled</span>':'<span class="pill st-good">Active</span>'}</td>
   <td class="r"><button class="btn sm" data-act="useredit" data-uid="${esc(u.id)}">Edit</button></td></tr>`).join('')}
  </tbody></table></div></div>
  <div class="panel"><h3>How sign-in works</h3><p class="small ink2">When you add someone, they receive an email with their sign-in email and a temporary password (you can also set the temporary password yourself and give it to them). They choose their own password the first time they sign in, and can reset it themselves with “Forgot your password?”. Lecturers can mark a day for ${cfg().editWindow} days after it; after that, an administrator reopens the day from the Academic calendar.</p></div>`;
}
function userModal(id){
  const u=id?{...DATA.users[id],id}:null;const P=progList();const asg=Object.fromEntries((u?.assign||[]).map(a=>[a.pid,a.slots||[]]));const self=u&&u.id===S.me.id;
  openModal(`${mhead(u?'Edit account':'Add lecturer')}<form id="userForm"><div class="mbody">
    <div class="grid2"><div class="field"><label for="uf-name">Full name</label><input type="text" id="uf-name" required value="${esc(u?.name)}"></div>
    <div class="field"><label for="uf-email">Email (used to sign in)</label><input type="email" id="uf-email" required autocapitalize="none" value="${esc(u?.email||u?.id||'')}" ${u?'readonly':''} placeholder="name@institute.lk">${u?'<span class="hint">The email can’t be changed. Delete the account and add it again with the new address.</span>':''}</div></div>
    <div class="grid3"><div class="field"><label for="uf-role">Role</label><select id="uf-role" ${self?'disabled':''}><option value="lecturer">Lecturer</option><option value="admin" ${u?.role==='admin'?'selected':''}>Administrator</option></select></div>
    <div class="field"><label for="uf-active">Status</label><select id="uf-active" ${self?'disabled':''}><option value="1">Active</option><option value="0" ${u&&u.active===false?'selected':''}>Disabled</option></select></div>
    <div class="field"><label for="uf-pw">${u?'New temporary password (optional)':'Temporary password (optional)'}</label><input type="text" id="uf-pw" autocomplete="off" placeholder="${u?'Leave blank to keep the current one':'Leave blank to email one automatically'}"><span class="hint">${PW_RULE}</span></div></div>
    <div class="field" id="uf-asg-wrap"><span class="lbl">Assigned classes</span><span class="hint">Tick a programme, then pick the lecture slots this lecturer teaches. Leave all slots unticked to give every slot.</span>
      <div class="tbl-wrap"><table class="t"><tbody>${P.map(p=>`<tr><td><label class="check"><input type="checkbox" class="uf-p" value="${p.id}" ${asg[p.id]?'checked':''}> <span><b>${esc(p.name)}</b> <span class="tiny muted">${esc(p.batch||'')}</span></span></label></td>
      <td><div class="slotpick">${range(1,p.slots).map(s=>`<label><input type="checkbox" class="uf-s" data-pid="${p.id}" value="${s}" ${(asg[p.id]||[]).includes(s)?'checked':''}> ${s}</label>`).join('')}</div></td></tr>`).join('')}</tbody></table></div></div>
    <div class="err" id="uf-err" role="alert"></div>
  </div><div class="mfoot">${u&&!self?`<button type="button" class="btn danger" data-act="userdel" data-uid="${esc(u.id)}" style="margin-right:auto">Delete…</button>`:''}<button type="button" class="btn" data-act="close">Cancel</button><button class="btn pri" type="submit" id="uf-go">${u?'Save':'Create account'}</button></div></form>`,true);
  const sync=()=>{$('#uf-asg-wrap').hidden=$('#uf-role').value==='admin'};sync();$('#uf-role').addEventListener('change',sync);
  document.querySelectorAll('.uf-s').forEach(cb=>cb.addEventListener('change',()=>{if(cb.checked)document.querySelector(`.uf-p[value="${cb.dataset.pid}"]`).checked=true}));
  $('#userForm').addEventListener('submit',async e=>{e.preventDefault();
    const err=t=>{$('#uf-err').textContent=t};
    const email=(u?u.id:$('#uf-email').value.trim().toLowerCase());const name=$('#uf-name').value.trim();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return err('Enter a valid email address.');
    if(!name)return err('Enter the person’s name.');
    if(!u&&DATA.users[email])return err('This email address already has an account.');
    const role=self?u.role:$('#uf-role').value,active=self?true:$('#uf-active').value==='1';
    const admins=Object.entries(DATA.users).filter(([k,x])=>x.role==='admin'&&x.active!==false&&k!==id).length;
    if(u&&u.role==='admin'&&(role!=='admin'||!active)&&admins===0)return err('Keep at least one active administrator.');
    const pw=$('#uf-pw').value;if(pw&&!pwOk(pw))return err('Temporary password: '+PW_RULE);
    const assign=[...document.querySelectorAll('.uf-p:checked')].map(cb=>({pid:cb.value,slots:[...document.querySelectorAll(`.uf-s[data-pid="${cb.value}"]:checked`)].map(x=>+x.value)}));
    $('#uf-go').disabled=true;err('');
    try{
      if(!u){
        try{await B.staff('create',{email,name,role,password:pw||undefined})}
        catch(ex){if(/already exists/i.test(ex.message||''))await B.staff('update',{email,name,role});else throw ex}
      }else{
        if(name!==u.name||role!==u.role)await B.staff('update',{email,name,role:role!==u.role?role:undefined});
        if(active!==(u.active!==false))await B.staff(active?'enable':'disable',{email});
        if(pw)await B.staff('resetPassword',{email,password:pw});
      }
      await Store.set('users/'+email,{email,name,role,active,assign:role==='admin'?[]:assign});
      closeModal();renderMain();
      toast(u?'Account saved.':pw?`Account created. Give ${name} the temporary password; they also get an email with their sign-in details.`:`Account created. ${name} will receive an email with a temporary password.`);
    }catch(ex){console.error(ex);err(ex.message||'Could not save the account.');$('#uf-go').disabled=false}
  });
}
function openPwModal(){
  openModal(`${mhead('Change password')}
  <form id="pwForm"><div class="mbody"><div class="field"><label for="pw-old">Current password</label><input type="password" id="pw-old" autocomplete="current-password" required></div>
    <div class="field"><label for="pw-new">New password</label><input type="password" id="pw-new" autocomplete="new-password" required><span class="hint">${PW_RULE}</span></div>
    <div class="field"><label for="pw-new2">Repeat new password</label><input type="password" id="pw-new2" autocomplete="new-password" required></div><div class="err" id="pw-err" role="alert"></div></div>
    <div class="mfoot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn pri" type="submit">Save password</button></div></form>`);
  $('#pwForm').addEventListener('submit',async e=>{e.preventDefault();
    const n=$('#pw-new').value;if(!pwOk(n)){$('#pw-err').textContent=PW_RULE;return}if(n!==$('#pw-new2').value){$('#pw-err').textContent='The two passwords don’t match.';return}
    try{await B.auth.changePassword($('#pw-old').value,n);closeModal();toast('Password saved.')}catch(er){$('#pw-err').textContent=er.message==='Email or password is incorrect.'?'Current password is incorrect.':er.message}
  });
}

/* ============ Reports ============ */
function vReports(){
  const P=progList(true);if(!P.length)return `<div class="pagehead"><div><h1>Attendance reports</h1><p>No programmes yet.</p></div></div>`;
  const R=S.rep;if(!R.pid||(R.pid!=='all'&&!prog(R.pid)))R.pid=(progList()[0]||P[0]).id;
  if(R.pid!=='all'&&prog(R.pid).status==='archived')Store.loadArchived(R.pid);
  const tabs=[['register','Register'],['progress','Progress'],['monthly','Monthly summary'],['compliance','Marking check']];
  if(R.tab==='register'&&R.pid==='all')R.pid=(progList()[0]||P[0]).id;
  const body={register:repRegister,progress:repProgress,monthly:repMonthly,compliance:repCompliance}[R.tab]();
  return `<div class="pagehead"><div><h1>Attendance reports</h1><p>Totals and percentages update as soon as attendance is saved.</p></div></div>
  <div class="row"><div class="seg" role="tablist">${tabs.map(t=>`<button role="tab" aria-selected="${R.tab===t[0]}" class="${R.tab===t[0]?'on':''}" data-act="reptab" data-tab="${t[0]}">${t[1]}</button>`).join('')}</div></div>
  ${body}`;
}
function repProgSelect(allowAll){const P=progList(true);return `<div class="field"><label for="rep-pid">Programme</label><select id="rep-pid" data-chg="reppid">${progOptions(S.rep.pid,P,allowAll?'All active programmes':'')}</select></div>`}
function repRegister(){
  const ps=pStats(S.rep.pid);const p=ps.p;const c=cfg();const today=D.today();
  const months=[...new Set(ps.days.map(d=>D.month(d.date)))];
  const fm=S.rep.month&&months.includes(S.rep.month)?S.rep.month:'all';
  const days=ps.days.filter(d=>fm==='all'||D.month(d.date)===fm);
  const studs=S.rep.inclW?ps.studs:ps.active;
  const weeks=[];days.forEach(d=>{let w=weeks.find(x=>x.wk===d.wk);if(!w)weeks.push(w={wk:d.wk,days:[]});w.days.push(d)});
  const split=p.split||3;
  const cellVal=(d,sl,sid)=>{if(!d.conducted.includes(sl))return d.date<=today?['','vq','·']:['','',''];const v=(((DATA.att[p.id+'__'+d.date]||{}).marks||{})[sl]||{})[sid]||'';
    if(!v)return ['','vq','?'];if(v==='P')return ['1','v1','1'];if(v==='A')return ['0','v0','0'];return [v,'v'+v,v]};
  const head1=weeks.map(w=>`<th colspan="${w.days.reduce((a,d)=>a+d.slots.length,0)}" class="wk">W${pad(w.wk)}</th>`).join('');
  const head2=weeks.map(w=>w.days.map((d,i)=>`<th colspan="${d.slots.length}" class="${i===w.days.length-1?'wk':''}" title="${D.long(d.date)}${d.note?' · '+esc(d.note):''}">${DOW[d.dow].toUpperCase()} ${D.short(d.date)}${d.extra?' *':''}</th>`).join('')).join('');
  const head3=weeks.map(w=>w.days.map((d,i)=>d.slots.map((s,j)=>`<th class="${s>split?'eve':''} ${i===w.days.length-1&&j===d.slots.length-1?'wk':''}">${s}</th>`).join('')).join('')).join('');
  const rows=studs.map(s=>{const r=ps.per[s.id];let att=0;
    const cells=weeks.map(w=>w.days.map((d,i)=>d.slots.map((sl,j)=>{const [,cls,txt]=cellVal(d,sl,s.id);const v=(((DATA.att[p.id+'__'+d.date]||{}).marks||{})[sl]||{})[s.id];if(d.conducted.includes(sl)&&isPresent(v,c))att++;return `<td class="v ${cls} ${sl>split&&!cls?'eve':''} ${i===w.days.length-1&&j===d.slots.length-1?'wk':''}">${txt}</td>`}).join('')).join('')).join('');
    return `<tr class="${s.status==='withdrawn'?'withdrawn':''}"><td class="stk0 mono">${pad(s.no||0)}</td><td class="stk1"><a href="#reports" data-act="student" data-sid="${s.id}" style="color:inherit;text-decoration:none"><b>${esc(s.first)}</b> ${esc(s.last)}</a></td>${cells}
      <td class="tot">${fm==='all'?r.att:att}</td><td class="tot">${fm==='all'?r.cond:''}</td><td class="tot"><span class="pill st-${r.status}" style="padding:1px 7px">${fmtPct(r.pct)}</span></td><td class="tot">${fmtPct(r.pctProg)}</td></tr>`}).join('');
  const foot=weeks.map(w=>w.days.map((d,i)=>d.slots.map((sl,j)=>{if(!d.conducted.includes(sl))return `<td class="${i===w.days.length-1&&j===d.slots.length-1?'wk':''}"></td>`;const m=((DATA.att[p.id+'__'+d.date]||{}).marks||{})[sl]||{};const n=ps.active.filter(s=>isPresent(m[s.id],c)).length;return `<td class="${i===w.days.length-1&&j===d.slots.length-1?'wk':''}" title="${n} present">${n}</td>`}).join('')).join('')).join('');
  return `<div class="panel"><div class="toolbar">${repProgSelect(false)}
    <div class="field"><label for="rep-month">Period</label><select id="rep-month" data-chg="repmonth"><option value="all">Whole programme</option>${months.map(m=>`<option value="${m}" ${m===fm?'selected':''}>${D.monthName(m)}</option>`).join('')}</select></div>
    <label class="check" style="padding-bottom:8px"><input type="checkbox" data-chg="repinclw" ${S.rep.inclW?'checked':''}> Include withdrawn</label><div class="spacer"></div>
    <div class="row"><button class="btn" data-act="expcsv" data-what="register">CSV</button><button class="btn pri" data-act="expxlsx" data-what="register">Download Excel</button></div></div>
    <div class="row small ink2"><span><b>${ps.planned}</b> planned slots (target ${ps.target})</span><span>·</span><span><b>${ps.condSlots}</b> held and marked</span><span>·</span><span>class average <b>${fmtPct(ps.avg)}</b></span><span>·</span><span>1 present, 0 absent, L late, E excused, ? not marked, · slot not marked yet, * make-up day</span></div></div>
  ${days.length?`<div class="reg-wrap" data-ks="reg"><table class="reg"><thead><tr><th class="stk0" rowspan="3">No</th><th class="stk1" rowspan="3" style="text-align:left">Student</th>${head1}<th rowspan="3" class="tot">Attended</th><th rowspan="3" class="tot">Held</th><th rowspan="3" class="tot">To date %</th><th rowspan="3" class="tot" title="Attended ÷ ${ps.planned} planned slots">Programme %</th></tr><tr>${head2}</tr><tr>${head3}</tr></thead>
  <tbody>${rows}</tbody><tfoot><tr><td class="stk0"></td><td class="stk1"><b>Present</b></td>${foot}<td colspan="4"></td></tr></tfoot></table></div>
  <p class="tiny muted">To date % = slots attended ÷ slots held and marked so far. Programme % = slots attended ÷ all ${ps.planned} planned slots, so it builds up to the final figure by the end of the programme.</p>`:`<div class="panel empty">No academic days in this period.</div>`}`;
}
function trendChart(ps){
  const c=cfg();const wks=Object.keys(ps.wkAgg).map(Number).sort((a,b)=>a-b).filter(w=>ps.wkAgg[w].cond);
  if(wks.length<1)return `<div class="empty small">The weekly trend appears once attendance has been marked.</div>`;
  const W=640,H=200,L=40,R=12,T=12,B=28;const n=ps.weeksTotal||wks[wks.length-1];
  const x=w=>L+(n<=1?0:(w-1)/(n-1))*(W-L-R);const y=v=>T+(1-v/100)*(H-T-B);
  const pts=wks.map(w=>({w,v:ps.wkAgg[w].att/ps.wkAgg[w].cond*100,a:ps.wkAgg[w].att,t:ps.wkAgg[w].cond}));
  const line=pts.map((p,i)=>(i?'L':'M')+x(p.w).toFixed(1)+' '+y(p.v).toFixed(1)).join(' ');
  const area=line+` L${x(pts[pts.length-1].w).toFixed(1)} ${y(0)} L${x(pts[0].w).toFixed(1)} ${y(0)} Z`;
  const ticksY=[0,25,50,75,100].map(v=>`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)" stroke-width="1"/><text x="${L-6}" y="${y(v)+4}" text-anchor="end">${v}%</text>`).join('');
  const step=n>16?4:n>8?2:1;const ticksX=range(1,n).filter(w=>w===1||w%step===0||w===n).map(w=>`<text x="${x(w)}" y="${H-8}" text-anchor="middle">W${w}</text>`).join('');
  const last=pts[pts.length-1];
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Weekly class attendance">${ticksY}${ticksX}
    <line x1="${L}" x2="${W-R}" y1="${y(c.threshold)}" y2="${y(c.threshold)}" stroke="var(--crit)" stroke-dasharray="4 4" stroke-width="1.2"/><text x="${W-R}" y="${y(c.threshold)-5}" text-anchor="end" style="fill:var(--crit)">${c.threshold}% minimum</text>
    <path d="${area}" fill="var(--accent-soft)" opacity=".7"/><path d="${line}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>
    ${pts.map(p=>`<circle cx="${x(p.w)}" cy="${y(p.v)}" r="${p===last?5:3.5}" fill="var(--accent)" stroke="var(--surface)" stroke-width="2"/><circle cx="${x(p.w)}" cy="${y(p.v)}" r="14" fill="transparent" class="hit" data-tip="Week ${p.w}: ${fmtPct(p.v)} (${p.a} of ${p.t} student-slots)"/>`).join('')}
    <text x="${x(last.w)}" y="${y(last.v)-10}" text-anchor="middle" style="fill:var(--ink);font-weight:600">${fmtPct(last.v)}</text></svg>`;
}
function progressTable(list,showProg){
  return `<div class="tbl-wrap"><table class="t"><thead><tr><th>No</th><th>Student</th>${showProg?'<th>Programme</th>':''}<th class="r">Attended / held</th><th class="r" style="min-width:110px">To date</th><th class="r">Programme %</th><th class="r" title="Best final % if the student attends every remaining slot">Best possible</th><th class="r">Late</th><th class="r">Excused</th><th>Status</th><th>Weekly</th></tr></thead><tbody>
  ${list.map(({s,r,ps})=>`<tr class="click ${s.status==='withdrawn'?'withdrawn':''}" data-act="student" data-sid="${s.id}"><td class="mono">${pad(s.no||0)}</td><td><b>${esc(sName(s))}</b></td>${showProg?`<td class="small">${esc(ps.p.name)}</td>`:''}
   <td class="r num">${r.att} / ${r.cond}</td><td class="r num"><b>${fmtPct(r.pct)}</b>${pbar(r.pct,r.status)}</td><td class="r num">${fmtPct(r.pctProg)}</td><td class="r num">${fmtPct(r.maxPct)}</td><td class="r num">${r.late||''}</td><td class="r num">${r.exc||''}</td><td>${pill(r.status)}</td><td>${weekStrip(r,ps)}</td></tr>`).join('')}</tbody></table></div>`;
}
function repProgress(){
  const c=cfg();
  if(S.rep.pid==='all'){const list=[];progList().forEach(p=>{const ps=pStats(p.id);ps.active.forEach(s=>list.push({s,r:ps.per[s.id],ps}))});
    list.sort((a,b)=>(a.r.pct??101)-(b.r.pct??101));
    return `<div class="panel"><div class="toolbar">${repProgSelect(true)}<div class="spacer"></div><div class="row"><button class="btn" data-act="expcsv" data-what="progress">CSV</button><button class="btn pri" data-act="expxlsx" data-what="progress">Download Excel</button></div></div>
      <div class="tbl-wrap"><table class="t"><thead><tr><th>Programme</th><th class="r">Students</th><th class="r">Week</th><th class="r" style="min-width:120px">Average to date</th><th style="min-width:160px">Students by status</th></tr></thead><tbody>
      ${progList().map(p=>{const ps=pStats(p.id);return `<tr class="click" data-act="openprog" data-pid="${p.id}"><td><b>${esc(p.name)}</b> <span class="tiny muted">${esc(p.batch||'')}</span></td><td class="r num">${ps.active.length}</td><td class="r num">W${pad(ps.curWk)}/${ps.weeksTotal}</td><td class="r num"><b>${fmtPct(ps.avg)}</b>${pbar(ps.avg,statusOf(ps.avg,null,c))}</td><td>${distBar(ps.dist)}</td></tr>`}).join('')}</tbody></table></div></div>
      <div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>All students, lowest attendance first</h2></div>${progressTable(list,true)}</div>`}
  const ps=pStats(S.rep.pid);const list=(S.rep.inclW?ps.studs:ps.active).map(s=>({s,r:ps.per[s.id],ps}));
  const srt=S.rep.sort||'no';if(srt==='pct')list.sort((a,b)=>(a.r.pct??101)-(b.r.pct??101));
  return `<div class="panel"><div class="toolbar">${repProgSelect(true)}<div class="field" style="flex:0 1 180px"><label for="rep-sort">Sort by</label><select id="rep-sort" data-chg="repsort"><option value="no">Register number</option><option value="pct" ${srt==='pct'?'selected':''}>Lowest attendance first</option></select></div>
    <label class="check" style="padding-bottom:8px"><input type="checkbox" data-chg="repinclw" ${S.rep.inclW?'checked':''}> Include withdrawn</label><div class="spacer"></div><div class="row"><button class="btn" data-act="expcsv" data-what="progress">CSV</button><button class="btn pri" data-act="expxlsx" data-what="progress">Download Excel</button></div></div>
    <div class="kpis"><div class="kpi"><span class="l">Class average to date</span><span class="v">${fmtPct(ps.avg)}</span><span class="s">${ps.condSlots} of ${ps.planned} slots held</span></div>
     <div class="kpi"><span class="l">Programme week</span><span class="v">${ps.curWk||'–'}<span class="muted" style="font-size:1rem"> / ${ps.weeksTotal}</span></span><span class="s">${D.long(ps.p.start)} – ${D.long(ps.p.end)}</span></div>
     <div class="kpi ${ps.dist.below+ps.dist.critical?'alert':''}"><span class="l">Below ${c.threshold}%</span><span class="v">${ps.dist.below+ps.dist.critical}</span><span class="s">${ps.dist.critical} cannot reach the minimum</span></div>
     <div class="kpi"><span class="l">On track</span><span class="v">${ps.dist.good}</span><span class="s">${ps.dist.watch} on watch (${c.threshold}–${c.watchBand}%)</span></div></div>
    <div><h3>Weekly class attendance</h3>${trendChart(ps)}</div></div>
  <div class="panel flush">${progressTable(list,false)}</div>`;
}
function repMonthly(){
  const c=cfg();const P=progList();const months=new Set();P.forEach(p=>pStats(p.id).days.forEach(d=>{if(d.date<=D.today())months.add(D.month(d.date))}));
  const ms=[...months].sort();if(!ms.length)return `<div class="panel empty">No attendance has been recorded yet.</div>`;
  const m=S.rep.mon&&ms.includes(S.rep.mon)?S.rep.mon:ms[ms.length-1];S.rep.mon=m;
  const rows=P.map(p=>{const ps=pStats(p.id);const ds=ps.days.filter(d=>D.month(d.date)===m);let held=0;ds.forEach(d=>held+=d.conducted.length);
    let A=0,C=0,below=0,perfect=0;const per=ps.active.map(s=>{let a=0,t=0;ps.per[s.id].recs.filter(r=>D.month(r.date)===m).forEach(r=>Object.values(r.v).forEach(v=>{if(!v)return;t++;if(isPresent(v,c))a++}));A+=a;C+=t;if(t&&a/t*100<c.threshold)below++;if(t&&a===t)perfect++;return {s,a,t}});
    return {p,ds,held,A,C,below,perfect,per,miss:ds.reduce((a,d)=>a+d.missing.length,0)}});
  const sel=S.rep.pid!=='all'&&rows.find(x=>x.p.id===S.rep.pid)||rows[0];
  return `<div class="panel"><div class="toolbar"><div class="field"><label for="rep-mon">Month</label><select id="rep-mon" data-chg="repmon">${ms.map(x=>`<option value="${x}" ${x===m?'selected':''}>${D.monthName(x)}</option>`).join('')}</select></div><div class="spacer"></div><button class="btn" data-act="expcsv" data-what="monthly">CSV</button></div>
  <div class="tbl-wrap"><table class="t"><thead><tr><th>Programme</th><th class="r">Academic days</th><th class="r">Slots held</th><th class="r">Unmarked slots</th><th class="r" style="min-width:120px">Attendance</th><th class="r">Below ${c.threshold}%</th><th class="r">Full attendance</th></tr></thead><tbody>
  ${rows.map(x=>`<tr class="click" data-act="monsel" data-pid="${x.p.id}" style="${x===sel?'background:var(--accent-soft)':''}"><td><b>${esc(x.p.name)}</b> <span class="tiny muted">${esc(x.p.batch||'')}</span></td><td class="r num">${x.ds.length}</td><td class="r num">${x.held}</td><td class="r num" style="${x.miss?'color:var(--crit)':''}">${x.miss}</td><td class="r num"><b>${fmtPct(x.C?x.A/x.C*100:null)}</b>${pbar(x.C?x.A/x.C*100:0,statusOf(x.C?x.A/x.C*100:null,null,c))}</td><td class="r num">${x.below}</td><td class="r num">${x.perfect}</td></tr>`).join('')}</tbody></table></div></div>
  ${sel?`<div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>${esc(sel.p.name)} · ${D.monthName(m)}</h2><span class="tiny muted">Click a programme above to switch</span></div><div class="tbl-wrap"><table class="t"><thead><tr><th>No</th><th>Student</th><th class="r">Attended</th><th class="r">Held</th><th class="r" style="min-width:120px">Month %</th><th class="r">Year to date</th></tr></thead><tbody>
  ${sel.per.map(({s,a,t})=>{const v=t?a/t*100:null;const r=pStats(sel.p.id).per[s.id];return `<tr class="click" data-act="student" data-sid="${s.id}"><td class="mono">${pad(s.no||0)}</td><td><b>${esc(sName(s))}</b></td><td class="r num">${a}</td><td class="r num">${t}</td><td class="r num"><b>${fmtPct(v)}</b>${pbar(v||0,statusOf(v,null,c))}</td><td class="r num">${fmtPct(r.pct)}</td></tr>`}).join('')}</tbody></table></div></div>`:''}`;
}
function repCompliance(){
  const P=S.rep.pid==='all'?progList():[prog(S.rep.pid)].filter(Boolean);const today=D.today();
  const rows=[];P.forEach(p=>{const ps=pStats(p.id);ps.days.filter(d=>d.date<=today).forEach(d=>{if(S.rep.allC||d.missing.length)rows.push({p,d})})});
  rows.sort((a,b)=>b.d.date.localeCompare(a.d.date));
  const lect=(p,sl)=>Object.values(DATA.users).filter(u=>u.role!=='admin'&&u.active!==false&&(u.assign||[]).some(a=>a.pid===p.id&&(!a.slots||!a.slots.length||a.slots.includes(sl)))).map(u=>u.name).join(', ');
  const total=rows.reduce((a,x)=>a+x.d.missing.length,0);
  return `<div class="panel"><div class="toolbar">${repProgSelect(true)}<label class="check" style="padding-bottom:8px"><input type="checkbox" data-chg="repallc" ${S.rep.allC?'checked':''}> Show fully marked days too</label></div>
    <p class="small ink2">Lecture slots that were scheduled on a past academic day but have no attendance saved. Students are not penalised for unmarked slots, so these need to be completed or the slot removed from the day in the Academic calendar.</p>
    <div class="notice ${total?'warn':'info'}">${total?`${total} lecture slot${total>1?'s':''} still need attendance.`:'Every held lecture slot has attendance saved.'}</div></div>
  ${rows.length?`<div class="panel flush"><div class="tbl-wrap"><table class="t"><thead><tr><th>Date</th><th>Programme</th><th>Slots</th><th>Missing — responsible lecturer</th><th></th></tr></thead><tbody>
  ${rows.map(({p,d})=>`<tr><td class="num">${D.nice(d.date)}<div class="tiny muted">W${pad(d.wk)}</div></td><td><b>${esc(p.name)}</b> <span class="tiny muted">${esc(p.batch||'')}</span></td>
    <td><div class="slotdots">${d.slots.map(s=>`<i class="${d.conducted.includes(s)?'ok':'miss'}" title="${d.conducted.includes(s)?`Marked by ${esc((d.meta[s]||{}).name||'')}`:'Not marked'}">${s}</i>`).join('')}</div></td>
    <td class="small">${d.missing.map(s=>`Slot ${s}: ${esc(lect(p,s)||'no lecturer assigned')}`).join('<br>')||'<span class="muted">Complete</span>'}</td>
    <td class="r">${d.missing.length?`<button class="btn sm" data-act="gomark" data-pid="${p.id}" data-date="${d.date}">Mark now</button>`:''}</td></tr>`).join('')}</tbody></table></div></div>`:''}`;
}

/* ============ Habitual absenteeism ============ */
function habList(pidFilter,min){const out=[];progList().filter(p=>pidFilter==='all'||p.id===pidFilter).forEach(p=>{const ps=pStats(p.id);ps.active.forEach(s=>{const r=ps.per[s.id];if(r.hab.stage>=min)out.push({p,s,r,ps})})});
  out.sort((a,b)=>b.r.hab.score-a.r.hab.score||(a.r.pct??0)-(b.r.pct??0));return out}
function vAbsenteeism(){
  const c=cfg();const H=S.hab;const P=progList();if(H.pid!=='all'&&!prog(H.pid))H.pid='all';
  const list=habList(H.pid,H.min);const all=habList(H.pid,1);
  const cnt=s=>all.filter(x=>x.r.hab.stage===s).length;
  return `<div class="pagehead"><div><h1>Habitual absenteeism</h1><p>Students are scored on several absence patterns, not only their percentage. A score of 1–${c.hab.s2-1} is an early alert, ${c.hab.s2}–${c.hab.s3-1} is habitual absence, and ${c.hab.s3} or more is critical. A student who can no longer reach ${c.threshold}% is always critical.</p></div>
   <div class="row"><button class="btn" data-act="expcsv" data-what="habitual">CSV</button><button class="btn pri" data-act="expxlsx" data-what="habitual">Download Excel</button></div></div>
  <div class="kpis"><div class="kpi ${cnt(3)?'alert':''}"><span class="l">Stage 3 · Critical</span><span class="v">${cnt(3)}</span><span class="s">score ${c.hab.s3}+ or cannot reach ${c.threshold}%</span></div><div class="kpi"><span class="l">Stage 2 · Habitual</span><span class="v">${cnt(2)}</span><span class="s">score ${c.hab.s2}–${c.hab.s3-1}</span></div><div class="kpi"><span class="l">Stage 1 · Early alert</span><span class="v">${cnt(1)}</span><span class="s">score 1–${c.hab.s2-1}</span></div></div>
  <div class="panel"><div class="toolbar"><div class="field"><label for="hab-pid">Programme</label><select id="hab-pid" data-chg="habpid">${progOptions(H.pid,P,'All active programmes')}</select></div>
    <div class="field"><label for="hab-min">Show</label><select id="hab-min" data-chg="habmin"><option value="2" ${H.min==2?'selected':''}>Stage 2 and 3 (habitual)</option><option value="3" ${H.min==3?'selected':''}>Stage 3 only</option><option value="1" ${H.min==1?'selected':''}>All stages incl. early alerts</option></select></div></div>
    <details><summary class="small" style="cursor:pointer;font-weight:600">How the score is calculated</summary><ul class="indic" style="margin-top:10px">
      <li><b>+4</b>Cannot reach ${c.threshold}% even with full attendance from now on</li><li><b>+3</b>Below ${c.threshold}% to date &nbsp;<span class="muted">(+1 if between ${c.threshold}% and ${c.watchBand}%)</span></li>
      <li><b>+2</b>${c.hab.streak}+ consecutive academic days fully absent &nbsp;<span class="muted">(+3 if ${c.hab.streak*2}+)</span></li><li><b>+2</b>Absent on ${c.hab.freq}+ academic days in the last 4 weeks</li>
      <li><b>+1</b>Same-weekday pattern: absent on ${c.hab.weekday}+ of one weekday, clearly more than the other</li><li><b>+1</b>Partial-day absence on ${c.hab.partial}+ days (attends morning, skips evening, or the reverse)</li>
      <li><b>+1</b>${c.hab.late}+ late arrivals</li><li><b>+1</b>Attendance down ${c.hab.decline}+ points in the last 4 weeks</li></ul><p class="tiny muted" style="margin-top:8px">Excused absences (E) do not count towards the patterns. Change these thresholds in Attendance rules.</p></details></div>
  ${list.length?list.map(({p,s,r,ps})=>`<div class="habcard s${r.hab.stage}">
    <div style="display:flex;flex-direction:column;gap:6px;min-width:0"><div class="row" style="gap:8px">${stagePill(r.hab.stage)}<span class="chip mono">score ${r.hab.score}</span></div>
      <h2><a href="#absenteeism" data-act="student" data-sid="${s.id}" style="color:inherit">${esc(sName(s))}</a></h2><span class="small muted">${esc(p.name)} · ${esc(p.batch||'')} · No. ${pad(s.no||0)}</span>
      <div class="row small"><span>To date <b>${fmtPct(r.pct)}</b></span><span>Best possible <b>${fmtPct(r.maxPct)}</b></span></div>${weekStrip(r,ps)}</div>
    <div style="min-width:0"><span class="eyebrow">Why flagged</span><ul class="indic" style="margin-top:6px">${r.hab.ind.map(i=>`<li><b>+${i.pts}</b><span>${esc(i.text)}</span></li>`).join('')}</ul></div>
    <div style="min-width:0;display:flex;flex-direction:column;gap:6px"><span class="eyebrow">Recommended action</span><p class="small">${STAGE[r.hab.stage].a}</p>
      <span class="tiny muted">Absent days: ${r.hab.absDays.slice(-6).map(d=>D.short(d.date)+(d.full?'':` (${d.a}/${d.n})`)).join(', ')}${r.hab.absDays.length>6?` and ${r.hab.absDays.length-6} earlier`:''}</span></div></div>`).join(''):`<div class="panel empty">No students at this stage. Change the filter to see early alerts.</div>`}`;
}

/* ============ Lecturer: my classes ============ */
function vMyClasses(){
  const P=myProgs();if(!P.length)return `<div class="pagehead"><div><h1>My class progress</h1><p>No classes are assigned to you yet.</p></div></div>`;
  if(!S.mc||!P.find(p=>p.id===S.mc))S.mc=P[0].id;const ps=pStats(S.mc);
  return `<div class="pagehead"><div><h1>My class progress</h1><p>Attendance to date for students in your classes. Students below the minimum are flagged so you can follow up.</p></div></div>
  <div class="panel"><div class="toolbar"><div class="field"><label for="mc-pid">Programme</label><select id="mc-pid" data-chg="mcpid">${progOptions(S.mc,P)}</select></div></div>${trendChart(ps)}</div>
  <div class="panel flush">${progressTable(ps.active.map(s=>({s,r:ps.per[s.id],ps})),false)}</div>`;
}

/* ============ Student profile ============ */
function studentModal(sid){
  const s={...DATA.students[sid],id:sid};const ps=pStats(s.pid);if(!ps)return;const r=ps.per[sid];const p=ps.p;const c=cfg();const today=D.today();
  const nS=p.slots;const cols=`grid-template-columns:44px repeat(${(p.weekdays||[]).length*nS},minmax(8px,1fr))`;
  const byWk={};ps.days.forEach(d=>{(byWk[d.wk]=byWk[d.wk]||[]).push(d)});
  let heat='';Object.keys(byWk).map(Number).sort((a,b)=>a-b).forEach(w=>{heat+=`<span class="tiny muted mono" style="line-height:14px">W${pad(w)}</span>`;const ds=byWk[w];let k=0;
    ds.slice(0,(p.weekdays||[]).length).forEach(d=>{for(let sl=1;sl<=nS;sl++){k++;if(!d.slots.includes(sl)){heat+='<i class="hv-x"></i>';continue}const v=d.conducted.includes(sl)?((((DATA.att[p.id+'__'+d.date]||{}).marks||{})[sl]||{})[sid]||''):'';heat+=`<i class="hv-${d.date>today?'x':v}" title="${D.nice(d.date)} slot ${sl}: ${v||(d.date>today?'upcoming':'not marked')}"></i>`}});
    for(;k<(p.weekdays||[]).length*nS;k++)heat+='<i class="hv-x"></i>'});
  openModal(`${mhead(sName(s),`${esc(p.name)} · ${esc(p.batch||'')} · No. ${pad(s.no||0)}${s.reg?' · '+esc(s.reg):''}${s.status==='withdrawn'?' · Withdrawn':''}`)}<div class="mbody">
   <div class="kpis"><div class="kpi"><span class="l">To date</span><span class="v">${fmtPct(r.pct)}</span><span class="s">${r.att} of ${r.cond} slots</span></div><div class="kpi"><span class="l">Programme %</span><span class="v">${fmtPct(r.pctProg)}</span><span class="s">of ${ps.planned} planned slots</span></div>
    <div class="kpi ${r.status==='critical'?'alert':''}"><span class="l">Best possible final</span><span class="v">${fmtPct(r.maxPct)}</span><span class="s">if every remaining slot is attended</span></div><div class="kpi"><span class="l">Absent · Late · Excused</span><span class="v">${r.abs-(c.excusedCounts?0:r.exc)} · ${r.late} · ${r.exc}</span><span class="s">lecture slots</span></div></div>
   <div class="row">${pill(r.status)}${stagePill(r.hab.stage)}${r.hab.stage?`<span class="chip mono">score ${r.hab.score}</span>`:''}</div>
   ${r.hab.ind.length?`<div><span class="eyebrow">Absence indicators</span><ul class="indic" style="margin-top:6px">${r.hab.ind.map(i=>`<li><b>+${i.pts}</b><span>${esc(i.text)}</span></li>`).join('')}</ul>${r.hab.stage?`<p class="small" style="margin-top:8px"><b>Recommended:</b> ${STAGE[r.hab.stage].a}</p>`:''}</div>`:''}
   <div><span class="eyebrow">Every lecture slot</span><div class="legend" style="margin:6px 0"><span><b class="hv-P"></b>Present</span><span><b class="hv-A"></b>Absent</span><span><b class="hv-L"></b>Late</span><span><b class="hv-E"></b>Excused</span><span><b class="hv-"></b>Not marked</span></div>
   <div class="tbl-wrap"><div class="heat" style="${cols};min-width:${44+(p.weekdays||[]).length*nS*10}px">${heat}</div></div><p class="tiny muted" style="margin-top:4px">Each row is a week; columns are ${(p.weekdays||[]).map(w=>DOW[w]).join(' then ')}, slots 1–${nS}.</p></div>
  </div><div class="mfoot"><button class="btn" data-act="close">Close</button></div>`,true);
}

/* ============ Rules ============ */
function vRules(){const c=cfg();const h=c.hab;
  const n=(id,l,v,hint,min,max)=>`<div class="field"><label for="${id}">${l}</label><input type="number" id="${id}" value="${v}" min="${min??0}" max="${max??100}">${hint?`<span class="hint">${hint}</span>`:''}</div>`;
  return `<div class="pagehead"><div><h1>Attendance rules</h1><p>These rules apply to every programme. Changes take effect immediately in all reports.</p></div></div>
  <form id="rulesForm" class="panel"><div class="field"><label for="r-org">Institute name</label><input type="text" id="r-org" value="${esc(c.orgName)}"></div>
   <h2>Minimum attendance</h2><div class="grid3">${n('r-thr','Minimum attendance %',c.threshold,'Students below this are flagged.')}${n('r-watch','Watch band up to %',c.watchBand,'Between the minimum and this value is “Watch”.')}${n('r-win','Lecturer editing window (days)',c.editWindow,'How long after a day lecturers can still change marks.',0,60)}</div>
   <div class="row"><label class="check"><input type="checkbox" id="r-late" ${c.lateCounts?'checked':''}> Late (L) counts as attended</label><label class="check"><input type="checkbox" id="r-exc" ${c.excusedCounts?'checked':''}> Excused (E) counts as attended</label></div>
   <h2>Habitual absence thresholds</h2><div class="grid3">${n('h-streak','Consecutive full days absent',h.streak,'',1,20)}${n('h-freq','Absent days in last 4 weeks',h.freq,'',1,20)}${n('h-weekday','Absences on one weekday',h.weekday,'',1,20)}${n('h-partial','Partial-day absences',h.partial,'',1,20)}${n('h-late','Late arrivals',h.late,'',1,50)}${n('h-decline','Drop in last 4 weeks (points)',h.decline,'',1,100)}</div>
   <h2>Absence stages</h2><div class="grid3">${n('h-s2','Stage 2 (habitual) from score',h.s2,'Scores below this are Stage 1 early alerts.',2,20)}${n('h-s3','Stage 3 (critical) from score',h.s3,'Students who can no longer reach the minimum are always Stage 3.',3,30)}</div>
   <div class="row end"><button class="btn pri" type="submit">Save rules</button></div></form>`}
async function saveRules(){const g=id=>+$('#'+id).value;
  const s={orgName:$('#r-org').value.trim()||DEF.orgName,threshold:g('r-thr'),watchBand:Math.max(g('r-watch'),g('r-thr')),editWindow:g('r-win'),lateCounts:$('#r-late').checked,excusedCounts:$('#r-exc').checked,
    hab:{streak:g('h-streak'),freq:g('h-freq'),weekday:g('h-weekday'),partial:g('h-partial'),late:g('h-late'),decline:g('h-decline'),s2:g('h-s2'),s3:Math.max(g('h-s3'),g('h-s2')+1)}};
  document.activeElement&&document.activeElement.blur();
  await guard(async()=>{await Store.set('config/settings',s);renderShell();renderMain()},'Rules saved.');}

/* ============ Import & backup ============ */
function vData(){
  if(!S.hist)S.hist={items:null,err:'',more:null};
  after(()=>{if(S.hist.items===null&&!S.hist.loading)loadHistory()});
  return `<div class="pagehead"><div><h1>Import & backup</h1><p>Bring in Excel sheets or records from the previous register, keep backup copies, and undo changes from the change history.</p></div></div>
  <div class="panel"><h2>Bring records across from the previous register</h2><p class="small ink2">In the previous register, open <b>Import & backup</b> and click <b>Download backup</b>. Then choose that file here. Every programme, student, calendar change and attendance mark is copied, and the result is checked against the file. It is safe to run more than once.</p>
   <div class="field" style="max-width:420px"><label for="rst-file">Backup file (.json)</label><input type="file" id="rst-file" accept=".json,application/json"></div><div id="rst-area">${rstHTML()}</div></div>
  <div class="grid2"><div class="panel"><h2>Download a backup</h2><p class="small ink2">Saves every programme, student, staff profile, calendar change and attendance mark as one file. Keep it somewhere safe, such as the institute’s shared drive. AWS also keeps continuous backups of the database for 35 days.</p><div><button class="btn pri" data-act="backup">Download backup</button></div></div>
   <div class="panel"><h2>Import an Excel attendance workbook</h2><p class="small ink2">One sheet per programme, students from row 5 with first name in column B and last name in column C, and lecture slots from column D in week order. 1 becomes Present and 0 becomes Absent.</p>
   <div class="field"><label for="imp-file">Workbook (.xlsx)</label><input type="file" id="imp-file" accept=".xlsx"></div></div></div>
  <div id="imp-area">${S.impHTML||''}</div>
  <div class="panel flush"><div class="panel-h" style="padding:16px 18px 0"><h2>Change history</h2><button class="btn sm" data-act="histload">Refresh</button></div>
   <p class="small ink2" style="padding:0 18px">Every change is recorded with who made it and the version before. Use “Restore earlier version” to undo a change.</p><div id="hist-area">${histHTML()}</div></div>`;
}
/* ---------- change history ---------- */
function describePath(path){const [col,id]=String(path||'').split('/');
  if(col==='att'){const i=id.lastIndexOf('__');const p=prog(id.slice(0,i));return `Attendance · ${p?esc(p.name)+' '+esc(p.batch||''):'(deleted programme)'} · ${D.nice(id.slice(i+2))}`}
  if(col==='students'){const s=DATA.students[id];return `Student · ${s?esc(sName(s)):esc(id)}`}
  if(col==='programmes'){const p=prog(id);return `Programme · ${p?esc(p.name)+' '+esc(p.batch||''):esc(id)}`}
  if(col==='calendar'){const p=prog(id);return `Calendar · ${p?esc(p.name)+' '+esc(p.batch||''):esc(id)}`}
  if(col==='users')return `Staff profile · ${esc(id)}`;
  if(col==='config')return 'Attendance rules';
  return esc(path)}
function histHTML(){const H=S.hist||{};
  if(H.err)return `<div class="notice err" style="margin:0 18px 16px">${esc(H.err)}</div>`;
  if(!H.items)return `<p class="muted small" style="padding:0 18px 16px">Loading…</p>`;
  if(!H.items.length)return `<div class="empty">No changes recorded yet.</div>`;
  const act={set:'Saved',merge:'Updated',del:'Deleted',restore:'Backup restored',import:'Excel import'};
  return `<div class="tbl-wrap"><table class="t"><thead><tr><th>When</th><th>Who</th><th>Change</th><th></th></tr></thead><tbody>
  ${H.items.map((h,i)=>`<tr><td class="num small">${esc(new Date(h.at).toLocaleString([], {day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}))}</td><td class="small">${esc(h.byName||h.by||'')}</td><td class="small"><b>${act[h.action]||esc(h.action)}</b> · ${String(h.path||'').includes('/')?describePath(h.path):esc(h.path||'')}</td>
   <td class="r">${h.before&&['set','merge','del'].includes(h.action)&&!/tooLarge/.test(h.before)?`<button class="btn sm ghost" data-act="histrestore" data-i="${i}">Restore earlier version</button>`:''}</td></tr>`).join('')}</tbody></table></div>
  ${H.more?`<div class="row" style="padding:10px 18px 16px"><button class="btn sm" data-act="histmore">Show older changes</button></div>`:''}`}
async function loadHistory(more){const H=S.hist;H.loading=true;
  try{const r=await B.audit.recent(100,more?H.more:null);H.items=more?(H.items||[]).concat(r.items):r.items;H.more=r.nextToken;H.err=''}
  catch(e){H.err='The change history could not be loaded. '+(e.message||'');H.items=H.items||[]}
  H.loading=false;const el=$('#hist-area');if(el)el.innerHTML=histHTML()}
function histRestoreModal(i){const h=S.hist.items[i];
  openModal(`${mhead('Restore earlier version?')}<div class="mbody"><p>${describePath(h.path)}</p><p class="small ink2">This puts back the version from before the change made by ${esc(h.byName||h.by||'someone')} on ${esc(new Date(h.at).toLocaleString())}. The restore itself is recorded too, so it can be undone.</p></div>
  <div class="mfoot"><button class="btn" data-act="close">Cancel</button><button class="btn pri" data-act="histrestorego" data-i="${i}">Restore</button></div>`)}
async function histRestore(i){const h=S.hist.items[i];const before=pj(h.before,null),afterV=pj(h.after,null);const path=h.path;const [col,id]=path.split('/');
  await guard(async()=>{
    await Store.set(path,before);
    if(col==='att'&&afterV){const k=id.lastIndexOf('__');for(const sl of Object.keys(afterV.marks||{}))if(!(before.marks||{})[sl])await Store.remove('AttendanceSlot',`${id.slice(0,k)}__${id.slice(k+2)}__${sl}`)}
    if(col==='calendar'&&afterV){for(const d of Object.keys(afterV.days||{}))if(!(before.days||{})[d])await Store.remove('CalendarDay',`${id}__${d}`)}
    changed();closeModal();S.hist.items=null;loadHistory()},'Earlier version restored.')}

/* ---------- Excel (ExcelJS, loaded only when needed) ---------- */
let XLp=null;function loadExcel(){if(!XLp)XLp=import('exceljs').then(m=>m.default||m).catch(e=>{XLp=null;throw new Error('Could not load the Excel component. Check your connection and try again.')});return XLp}
function cellVal(v){if(v==null)return null;if(typeof v==='object'){if(v instanceof Date)return v;if('result' in v)return cellVal(v.result);if(Array.isArray(v.richText))return v.richText.map(t=>t.text).join('');if('text' in v)return v.text;return null}return v}
function sheetAOA(ws){const out=[];ws.eachRow({includeEmpty:true},(row,r)=>{const arr=[];row.eachCell({includeEmpty:true},(c,ci)=>{arr[ci-1]=c.isMerged&&c.master!==c?null:cellVal(c.value)});for(let k=0;k<arr.length;k++)if(arr[k]===undefined)arr[k]=null;out[r-1]=arr});for(let k=0;k<out.length;k++)if(!out[k])out[k]=[];return out}
let IMP=null;
async function handleImportFile(f){
  const show=h=>{S.impHTML=h;const el=$('#imp-area');if(el)el.innerHTML=h};show('<div class="panel"><p class="muted small">Reading workbook…</p></div>');
  try{if(!/\.xlsx$/i.test(f.name))throw new Error('Save the workbook as an Excel .xlsx file first (File › Save As › Excel Workbook).');
    const E=await loadExcel();const wb=new E.Workbook();await wb.xlsx.load(await f.arrayBuffer());
    IMP=wb.worksheets.map((ws,i)=>{const aoa=sheetAOA(ws);const name=ws.name;
      const title=String((aoa[0]||[])[1]||'');const bm=title.match(/batch\s*0*(\d+)/i);
      const dayHdr=[];for(let c=3;c<3+12&&c<(aoa[1]||[]).length;c++){const v=String((aoa[1]||[])[c]||'').trim().slice(0,3).toUpperCase();if(v&&!dayHdr.includes(v))dayHdr.push(v)}
      const wdays=dayHdr.map(x=>['SUN','MON','TUE','WED','THU','FRI','SAT'].indexOf(x)).filter(x=>x>=0);
      const studs=[];let marks=0;for(let r=4;r<aoa.length;r++){const row=aoa[r]||[];if(!row[1])continue;studs.push(row);for(let c=3;c<row.length;c++)if(row[c]===0||row[c]===1)marks++}
      return {i,name:name.trim().replace(/\s*-\s*/,' – '),batch:bm?'Batch '+pad(bm[1]):'',weekdays:wdays.length?wdays:[2,3],studs,marks,aoa,on:studs.length>0}});
    show(`<div class="panel"><h2>Sheets found</h2><div class="tbl-wrap"><table class="t"><thead><tr><th></th><th>Programme name</th><th>Batch</th><th>Students</th><th>Marks</th></tr></thead><tbody>
      ${IMP.map(s=>`<tr><td><input type="checkbox" class="imp-on" data-i="${s.i}" ${s.on?'checked':''} aria-label="Import ${esc(s.name)}"></td><td><input type="text" class="imp-name" data-i="${s.i}" value="${esc(s.name)}"></td><td><input type="text" class="imp-batch" data-i="${s.i}" value="${esc(s.batch)}" style="max-width:120px"></td><td class="num">${s.studs.length}</td><td class="num">${s.marks}</td></tr>`).join('')}</tbody></table></div>
      <div class="grid3" style="margin-top:12px"><div class="field"><label for="imp-start">First academic day (Week 1, first day)</label><input type="date" id="imp-start" required></div><div class="field"><label for="imp-weeks">Academic weeks</label><input type="number" id="imp-weeks" value="24"></div><div class="field"><label for="imp-slots">Slots per day</label><input type="number" id="imp-slots" value="6"></div></div>
      <div class="row" style="margin-top:12px"><button class="btn pri" data-act="impgo">Import selected sheets</button><span class="tiny muted" id="imp-prog"></span></div></div>`);
  }catch(e){show(`<div class="panel"><div class="notice err">${esc(e.message||'This file could not be read as an Excel workbook.')}</div></div>`)}
}
async function pool(tasks,n,onDone){let i=0,done=0;const errs=[];
  const worker=async()=>{while(i<tasks.length){const k=i++;try{await tasks[k]()}catch(e){errs.push({k,e})}done++;onDone&&onDone(done,tasks.length)}};
  await Promise.all(Array.from({length:Math.min(n,tasks.length)},worker));return errs}
async function runImport(){
  const start=$('#imp-start').value;if(!start){toast('Enter the first academic day so marks land on the right dates.',true);return}
  const weeks=+$('#imp-weeks').value||24,slots=+$('#imp-slots').value||6;const sel=IMP.filter(s=>document.querySelector(`.imp-on[data-i="${s.i}"]`).checked);
  const m0=D.monday(start);const at=new Date().toISOString();const tasks=[];const docs=[];
  for(const s of sel){const pid='p-'+uid('').slice(1,10);const wd=s.weekdays;const perWeek=wd.length*slots;
    docs.push(['programmes/'+pid,{name:document.querySelector(`.imp-name[data-i="${s.i}"]`).value.trim(),batch:document.querySelector(`.imp-batch[data-i="${s.i}"]`).value.trim(),level:(s.name.split(/\s/)[0]||''),start,end:D.add(m0,weeks*7-1),weekdays:wd,weeks,slots,split:Math.ceil(slots/2),status:'active',order:s.i+1,created:at}]);
    const att={};
    for(let k=0;k<s.studs.length;k++){const row=s.studs[k];const sid=pid+'-s'+pad(k+1);
      docs.push(['students/'+sid,{pid,no:k+1,first:String(row[1]).trim(),last:String(row[2]||'').trim(),reg:'',status:'active'}]);
      for(let c=3;c<row.length&&c<3+weeks*perWeek;c++){const v=row[c];if(v!==0&&v!==1)continue;const idx=c-3;const wk=Math.floor(idx/perWeek);const di=Math.floor((idx%perWeek)/slots);const sl=idx%slots+1;
        const date=D.add(m0,wk*7+((wd[di]+6)%7));const a=att[date]||(att[date]={pid,date,marks:{},meta:{}});(a.marks[sl]=a.marks[sl]||{})[sid]=v===1?'P':'A';a.meta[sl]={by:S.me.id,name:'Excel import',at}}}
    for(const d of Object.keys(att))docs.push(['att/'+pid+'__'+d,att[d]]);
  }
  await guard(async()=>{
    // programmes first, then everything else in parallel
    const progs=docs.filter(d=>d[0].startsWith('programmes/')),rest=docs.filter(d=>!d[0].startsWith('programmes/'));
    for(const [p,v] of progs)await Store.set(p,v,{audit:false});
    const errs=await pool(rest.map(([p,v])=>()=>Store.set(p,v,{audit:false})),6,(n,t)=>setText('imp-prog',`Saving ${n} of ${t} records…`));
    if(errs.length)throw new Error(`${errs.length} records could not be saved. Import the workbook again; existing records are not duplicated.`);
    await Store.log('import','Excel workbook · '+sel.length+' sheets',null,null);
    IMP=null;S.impHTML='';toast(`Imported ${sel.length} programme${sel.length!==1?'s':''}.`);go('programmes');
  });
}
async function makeBackup(){const out={};const add=(col,m)=>Object.entries(m).forEach(([id,v])=>out[col+'/'+id]=v);
  out['config/settings']=DATA.settings;COLS.forEach(c=>add(c,DATA[c]));
  await saveFile(`attendance-backup-${D.today()}.json`,JSON.stringify({kind:'attendance-register-backup',version:2,created:new Date().toISOString(),docs:out},null,1))}
/* ---------- restore / bring records across ---------- */
function backupPlan(docs){
  const plan={config:[],programmes:[],students:[],users:[],calendar:[],att:[]};const oldAccounts=[];
  for(const [p,v] of Object.entries(docs||{})){const parts=p.split('/');if(parts.length!==2||!parts[1])continue;const col=parts[0];if(!plan[col]||v==null)continue;
    if(col==='users'){const email=String(v.email||(parts[1].includes('@')?parts[1]:'')).toLowerCase();if(v.hash||!email){oldAccounts.push(v);continue}plan.users.push(['users/'+email,{...v,email,username:email}]);continue}
    plan[col].push([p,v])}
  let marks=0,slots=0;plan.att.forEach(([,v])=>Object.values(v.marks||{}).forEach(m=>{slots++;marks+=Object.values(m||{}).filter(Boolean).length}));
  const calDays=plan.calendar.reduce((a,[,v])=>a+Object.keys(v.days||{}).length,0);
  return {plan,oldAccounts,marks,slots,calDays}}
const setText=(id,t)=>{const el=document.getElementById(id);if(el)el.textContent=t};
function rstHTML(){const R=S.rst;if(!R)return '';if(R.err)return `<div class="notice err" style="margin-top:10px">${esc(R.err)}</div>`;
  return R.info+`<div class="row" style="margin-top:10px"><button class="btn pri" data-act="rstgo" ${R.busy?'disabled':''}>Copy records into the register</button><span class="tiny muted" id="rst-prog">${esc(R.prog||'')}</span></div><div id="rst-result">${R.result||''}</div>`}
function refreshRst(){const el=$('#rst-area');if(el)el.innerHTML=rstHTML()}
async function handleRestore(f){
  try{const j=JSON.parse(await f.text());if(!j||j.kind!=='attendance-register-backup'||!j.docs)throw new Error('This file is not an attendance register backup.');
    const P=backupPlan(j.docs);const pl=P.plan;
    S.rst={docs:j.docs,name:f.name,prog:'',result:'',busy:false,info:`<div class="notice info" style="margin-top:10px"><span>Backup from ${esc(new Date(j.created).toLocaleString())} contains <b>${pl.programmes.length}</b> programmes, <b>${pl.students.length}</b> students, <b>${P.marks.toLocaleString()}</b> attendance marks in ${P.slots} lecture slots, ${P.calDays} calendar change${P.calDays===1?'':'s'}${pl.config.length?' and the attendance rules':''}.</span></div>
    ${P.oldAccounts.length?`<div class="notice warn" style="margin-top:10px">${P.oldAccounts.length} sign-in account${P.oldAccounts.length>1?'s':''} from the previous register can’t be moved, because passwords are never copied between systems: ${P.oldAccounts.map(u=>esc(u.name||u.username||'')).join(', ')}. Add the people who still need access under Lecturers & access, using their email addresses.</div>`:''}
    <p class="small ink2" style="margin-top:10px">Records with the same name are replaced with the version in the file; nothing else is removed.</p>`};
  }catch(e){S.rst={err:e.message||'Could not read this file.'}}
  refreshRst()}
function verifyRestore(P){const pl=P.plan;const miss=[];
  pl.programmes.forEach(([p])=>{if(!DATA.programmes[p.split('/')[1]])miss.push(p)});
  pl.students.forEach(([p,v])=>{const s=DATA.students[p.split('/')[1]];if(!s||s.first!==v.first||s.pid!==v.pid)miss.push(p)});
  let ok=0,bad=0;pl.att.forEach(([p,v])=>{const cur=DATA.att[p.split('/')[1]];Object.entries(v.marks||{}).forEach(([sl,m])=>Object.entries(m||{}).forEach(([sid,val])=>{if(!val)return;if(cur&&cur.marks[sl]&&cur.marks[sl][sid]===val)ok++;else{bad++;if(!miss.includes(p))miss.push(p)}}))});
  pl.calendar.forEach(([p,v])=>{const cur=(DATA.calendar[p.split('/')[1]]||{}).days||{};Object.keys(v.days||{}).forEach(d=>{if(!cur[d])miss.push(p+' '+d)})});
  return {miss,ok,bad}}
async function runRestore(){const R=S.rst;if(!R||!R.docs||R.busy)return;const P=backupPlan(R.docs);const pl=P.plan;
  const prog=t=>{R.prog=t;setText('rst-prog',t)};R.busy=true;R.result='';refreshRst();
  try{await guard(async()=>{
    for(const [p,v] of [...pl.config,...pl.programmes])await Store.set(p,v,{audit:false});
    const rest=[...pl.students,...pl.users,...pl.calendar,...pl.att];
    let errs=await pool(rest.map(([p,v])=>()=>Store.set(p,v,{audit:false})),6,(n,t)=>prog(`Copying ${n} of ${t} records…`));
    if(errs.length){prog('Retrying a few records…');errs=await pool(errs.map(x=>()=>Store.set(rest[x.k][0],rest[x.k][1],{audit:false})),3)}
    prog('Checking every record against the file…');
    const V=verifyRestore(P);
    await Store.log('restore',`Backup file ${R.name||''}: ${pl.programmes.length} programmes, ${pl.students.length} students, ${V.ok} marks`,null,null);
    R.result=V.miss.length||errs.length
      ?`<div class="notice err" style="margin-top:10px">${V.miss.length} record${V.miss.length!==1?'s':''} did not copy correctly (${V.bad} marks). Check your connection and click “Copy records into the register” again; it is safe to repeat.</div>`
      :`<div class="notice info" style="margin-top:10px"><span><b>Verified.</b> All ${pl.programmes.length} programmes, ${pl.students.length} students and ${V.ok.toLocaleString()} attendance marks in the register match the backup file exactly.</span></div>`;
  })}finally{R.busy=false;R.prog='';refreshRst();if(S.hist){S.hist.items=null;loadHistory()}}
}

/* ============ export ============ */
async function saveFile(name,data){
  const blob=data instanceof Blob?data:new Blob([data]);const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1500);
}
const csvOf=aoa=>'﻿'+aoa.map(r=>r.map(v=>{v=v==null?'':String(v);return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}).join(',')).join('\r\n');
const slug=s=>String(s).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
function registerAOA(pid){
  const ps=pStats(pid);const p=ps.p;const c=cfg();const days=ps.days;const studs=S.rep.inclW?ps.studs:ps.active;
  const r1=['No','Student',''],r2=['','',''],r3=['','',''],r4=['','First name','Last name'];const merges=[];let col=3;
  let wk=null,wkStart=3;
  days.forEach(d=>{if(d.wk!==wk){if(wk!==null&&col-1>wkStart)merges.push({s:{r:0,c:wkStart},e:{r:0,c:col-1}});wk=d.wk;wkStart=col;r1[col]='W'+pad(d.wk)}
    if(d.slots.length>1)merges.push({s:{r:1,c:col},e:{r:1,c:col+d.slots.length-1}});
    d.slots.forEach((s,i)=>{if(i===0){r2[col]=DOW[d.dow].toUpperCase()+' '+D.short(d.date)}r3[col]=sessionOf(p,s);r4[col]=s;if(r1[col]==null)r1[col]='';if(r2[col]==null)r2[col]='';col++})});
  if(wk!==null&&col-1>wkStart)merges.push({s:{r:0,c:wkStart},e:{r:0,c:col-1}});
  const lastCol=col-1;const L=i=>{let s='';i++;while(i>0){const m=(i-1)%26;s=String.fromCharCode(65+m)+s;i=Math.floor((i-1)/26)}return s};
  r1.push('Attended','Held','To date %','Programme %');[r2,r3,r4].forEach(r=>r.push('','','',''));
  const rows=studs.map((s,k)=>{const row=[s.no||k+1,s.first,s.last];const rr=k+5;
    days.forEach(d=>d.slots.forEach(sl=>{if(!d.conducted.includes(sl)){row.push(null);return}const v=(((DATA.att[p.id+'__'+d.date]||{}).marks||{})[sl]||{})[s.id]||'';row.push(v===''?null:isPresent(v,c)?1:0)}));
    const rng=`${L(3)}${rr}:${L(lastCol)}${rr}`;
    const r=ps.per[s.id];const r1=v=>Math.round(v*10)/10;
    row.push({t:'n',v:r.att,f:`SUM(${rng})`},{t:'n',v:r.cond,f:`COUNT(${rng})`},{t:'n',v:r.pct==null?0:r1(r.pct),f:`IF(${L(lastCol+2)}${rr}=0,0,ROUND(${L(lastCol+1)}${rr}/${L(lastCol+2)}${rr}*100,1))`},{t:'n',v:r1(r.pctProg||0),f:`ROUND(${L(lastCol+1)}${rr}/${ps.planned}*100,1)`});return row});
  return {aoa:[r1,r2,r3,r4,...rows],merges,title:`${p.batch||''} ${p.name}`.trim(),lastCol};
}
function progressAOA(){const P=S.rep.pid==='all'?progList():[prog(S.rep.pid)];const out=[['Programme','Batch','No','First name','Last name','Student ID','Attended','Held','To date %','Planned slots','Programme %','Best possible %','Late','Excused','Status','Absence stage','Score']];
  P.forEach(p=>{const ps=pStats(p.id);(S.rep.inclW?ps.studs:ps.active).forEach(s=>{const r=ps.per[s.id];out.push([p.name,p.batch,s.no,s.first,s.last,s.reg,r.att,r.cond,r.pct==null?'':+r.pct.toFixed(1),ps.planned,+(r.pctProg||0).toFixed(1),+(r.maxPct||0).toFixed(1),r.late,r.exc,STL[r.status],r.hab.stage?STAGE[r.hab.stage].t:'',r.hab.score])})});return out}
function habAOA(){const out=[['Stage','Score','Programme','Batch','No','Student','To date %','Best possible %','Indicators','Recommended action','Absent days']];
  habList(S.hab.pid,S.hab.min).forEach(({p,s,r})=>out.push([STAGE[r.hab.stage].t,r.hab.score,p.name,p.batch,s.no,sName(s),r.pct==null?'':+r.pct.toFixed(1),+(r.maxPct||0).toFixed(1),r.hab.ind.map(i=>`(+${i.pts}) ${i.text}`).join('; '),STAGE[r.hab.stage].a,r.hab.absDays.map(d=>d.date).join(', ')]));return out}
function monthlyAOA(){const c=cfg();const m=S.rep.mon;const out=[['Month','Programme','Batch','No','Student','Attended','Held','Month %']];
  progList().forEach(p=>{const ps=pStats(p.id);ps.active.forEach(s=>{let a=0,t=0;ps.per[s.id].recs.filter(r=>D.month(r.date)===m).forEach(r=>Object.values(r.v).forEach(v=>{if(!v)return;t++;if(isPresent(v,c))a++}));out.push([D.monthName(m),p.name,p.batch,s.no,sName(s),a,t,t?+(a/t*100).toFixed(1):''])})});return out}
async function xlsxBlob(sheetName,aoa,opts){
  const E=await loadExcel();const wb=new E.Workbook();wb.creator='Attendance Register';
  const ws=wb.addWorksheet(String(sheetName||'Sheet1').slice(0,31).replace(/[\\/?*\[\]:]/g,' ')||'Sheet1');
  aoa.forEach(row=>{const r=[];for(let i=0;i<row.length;i++){const v=row[i];r[i]=v&&typeof v==='object'&&!(v instanceof Date)&&v.f?{formula:v.f,result:v.v}:(v===undefined?null:v)}ws.addRow(r)});
  (opts&&opts.merges||[]).forEach(m=>ws.mergeCells(m.s.r+1,m.s.c+1,m.e.r+1,m.e.c+1));
  (opts&&opts.widths||[]).forEach((w,i)=>{ws.getColumn(i+1).width=w});
  if(opts&&opts.freeze)ws.views=[{state:'frozen',xSplit:opts.freeze[0],ySplit:opts.freeze[1]}];
  ws.getRow(1).font={bold:true};
  const buf=await wb.xlsx.writeBuffer();return new Blob([buf],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})}
async function exportReport(what,fmt){
  try{
    if(what==='register'){const R=registerAOA(S.rep.pid);
      if(fmt==='csv')return saveFile(slug(R.title)+'-register.csv',csvOf(R.aoa.map(r=>Array.from(r,v=>v&&v.f?v.v:v))));
      return saveFile(slug(R.title)+'-register.xlsx',await xlsxBlob(R.title,R.aoa,{merges:R.merges,widths:[5,14,14,...Array(R.lastCol-2).fill(4),9,7,10,12],freeze:[3,4]}))}
    const aoa=what==='progress'?progressAOA():what==='habitual'?habAOA():monthlyAOA();const name=`attendance-${what}-${D.today()}`;
    if(fmt==='csv')return saveFile(name+'.csv',csvOf(aoa));
    return saveFile(name+'.xlsx',await xlsxBlob(what,aoa,{widths:aoa[0].map((h,i)=>Math.min(60,Math.max(8,...aoa.map(r=>String(r[i]??'').length))))}));
  }catch(e){console.error(e);toast(e.message||'Export failed.',true)}
}

/* ============ events ============ */
document.addEventListener('click',async e=>{
  const g=e.target.closest('[data-go]');if(g){e.preventDefault();go(g.dataset.go);return}
  const el=e.target.closest('[data-act]');
  if(!el){if(e.target.id==='modal'&&!$('#modal').dataset.forced)closeModal();return}
  const a=el.dataset.act;const ds=el.dataset;
  if(el.tagName==='A')e.preventDefault();
  switch(a){
    case 'close':if(!$('#modal').dataset.forced)closeModal();break;
    case 'logout':logout();break;
    case 'reload':location.reload();break;
    case 'forgot':renderForgot(($('#li-user')||{}).value||'');break;
    case 'tologin':renderLogin();break;
    case 'claimadmin':claimAdmin();break;
    case 'pw':openPwModal();break;
    case 'histload':S.hist={items:null,err:'',more:null};$('#hist-area').innerHTML=histHTML();loadHistory();break;
    case 'histmore':loadHistory(true);break;
    case 'histrestore':histRestoreModal(+ds.i);break;
    case 'histrestorego':histRestore(+ds.i);break;
    case 'openreg':S.rep.pid=ds.pid;S.rep.tab='register';go('reports');break;
    case 'openprog':S.rep.pid=ds.pid;renderMain();break;
    case 'gomark':if(S.draft&&S.draft.dirty&&S.draft.key!==ds.pid+'|'+ds.date){toast('Save or discard your changes first.',true);break}S.mk.pid=ds.pid;S.mk.date=ds.date;go('attendance');break;
    case 'student':studentModal(ds.sid);break;
    case 'cyc':{const sl=ds.slot,sid=ds.sid;const m=S.draft.marks[sl]=S.draft.marks[sl]||{};m[sid]=CYCLE[m[sid]||''];S.draft.dirty=true;renderMain();break}
    case 'allp':case 'colp':{const p=prog(S.mk.pid);const day=progDays(p).find(d=>d.date===S.mk.date);const slots=a==='colp'?[+ds.slot]:day.slots.filter(s=>myAssign(p.id).includes(s));
      studentsOf(p.id,false).forEach(s=>slots.forEach(sl=>{const m=S.draft.marks[sl]=S.draft.marks[sl]||{};if(a==='colp'||!m[s.id])m[s.id]='P'}));S.draft.dirty=true;renderMain();break}
    case 'savemk':saveMarks();break;
    case 'discard':S.draft=null;renderMain();break;
    case 'calsel':{const d=ds.date;S.cal.sel.has(d)?S.cal.sel.delete(d):S.cal.sel.add(d);renderMain();break}
    case 'calclear':S.cal.sel.clear();renderMain();break;
    case 'calselacad':{const p=prog(S.cal.pid);progDays(p).filter(d=>D.month(d.date)===S.cal.month).forEach(d=>S.cal.sel.add(d.date));renderMain();break}
    case 'calmonth':S.cal.month=ds.m;renderMain();break;
    case 'calapply':calApply(ds.op);break;
    case 'progedit':progModal(ds.pid);break;
    case 'progdup':progModal(ds.pid,true);break;
    case 'progdel':{const p=prog(ds.pid);const n=studentsOf(p.id,true).length;openModal(`${mhead('Delete programme?')}<div class="mbody"><p>This permanently deletes <b>${esc(p.name)}</b> (${esc(p.batch)}), its ${n} students and all their attendance. A backup file of the whole register downloads first. Archive it instead to keep the history.</p></div><div class="mfoot"><button class="btn" data-act="close">Cancel</button><button class="btn danger" data-act="progdelgo" data-pid="${p.id}">Delete permanently</button></div>`);break}
    case 'progdelgo':await guard(async()=>{const pid=ds.pid;await makeBackup();for(const id of Object.keys(DATA.att).filter(k=>DATA.att[k].pid===pid))await Store.del('att/'+id);for(const s of studentsOf(pid,true))await Store.del('students/'+s.id);await Store.del('calendar/'+pid);await Store.del('programmes/'+pid);closeModal();S.prog.stu=null;renderMain()},'Programme deleted.');break;
    case 'stu':S.prog.stu=ds.pid;renderMain();window.scrollTo(0,0);break;
    case 'stuback':S.prog.stu=null;renderMain();break;
    case 'stuedit':stuModal(ds.pid,ds.sid);break;
    case 'studel':openModal(`${mhead('Delete student?')}<div class="mbody"><p>This removes <b>${esc(sName(DATA.students[ds.sid]))}</b> from the register. Their marks stay in the attendance records but are no longer shown. To keep them in reports, set the status to Withdrawn instead.</p></div><div class="mfoot"><button class="btn" data-act="close">Cancel</button><button class="btn danger" data-act="studelgo" data-sid="${ds.sid}">Delete student</button></div>`);break;
    case 'studelgo':await guard(async()=>{await Store.del('students/'+ds.sid);closeModal();renderMain()},'Student deleted.');break;
    case 'stubulk':bulkModal(ds.pid);break;
    case 'bulkgo':{const list=parseBulk();if(!list.length){toast('Paste at least one student.',true);break}const pid=ds.pid;let no=Math.max(0,...studentsOf(pid,true).map(x=>x.no||0));
      await guard(async()=>{for(const s of list){no++;await Store.set('students/'+pid+'-'+uid('s').slice(2,9),{pid,no,...s,status:'active'})}closeModal();renderMain()},`Added ${list.length} students.`);break}
    case 'useredit':userModal(ds.uid);break;
    case 'userdel':{const u=DATA.users[ds.uid];openModal(`${mhead('Delete account?')}<div class="mbody"><p>${esc(u.name)} (${esc(u.username)}) will no longer be able to sign in. Attendance they saved stays in the register.</p></div><div class="mfoot"><button class="btn" data-act="close">Cancel</button><button class="btn danger" data-act="userdelgo" data-uid="${ds.uid}">Delete account</button></div>`);break}
    case 'userdelgo':{const others=Object.entries(DATA.users).filter(([k,x])=>k!==ds.uid&&x.role==='admin'&&x.active!==false).length;if(DATA.users[ds.uid].role==='admin'&&!others){toast('Keep at least one active administrator.',true);break}await guard(async()=>{await B.staff('delete',{email:ds.uid});await Store.del('users/'+ds.uid);closeModal();renderMain()},'Account deleted.');break}
    case 'reptab':S.rep.tab=ds.tab;renderMain();break;
    case 'monsel':S.rep.pid=ds.pid;renderMain();break;
    case 'expcsv':exportReport(ds.what,'csv');break;
    case 'expxlsx':exportReport(ds.what,'xlsx');break;
    case 'impgo':runImport();break;
    case 'backup':makeBackup();break;
    case 'rstgo':runRestore();break;
  }
});
document.addEventListener('change',e=>{
  const el=e.target;
  if(el.id==='imp-file'&&el.files[0])return handleImportFile(el.files[0]);
  if(el.id==='rst-file'&&el.files[0])return handleRestore(el.files[0]);
  const k=el.dataset&&el.dataset.chg;if(!k)return;
  if(k==='mkpid'||k==='mkdate'){if(S.draft&&S.draft.dirty){toast('Save or discard your changes first.',true);el.value=k==='mkpid'?S.mk.pid:S.mk.date;return}
    if(k==='mkpid'){S.mk.pid=el.value;S.mk.date=null}else S.mk.date=el.value}
  else if(k==='calpid'){S.cal.pid=el.value;S.cal.sel.clear();S.cal.month=null}
  else if(k==='reppid')S.rep.pid=el.value;
  else if(k==='repmonth')S.rep.month=el.value;
  else if(k==='repmon')S.rep.mon=el.value;
  else if(k==='repsort')S.rep.sort=el.value;
  else if(k==='repinclw')S.rep.inclW=el.checked;
  else if(k==='repallc')S.rep.allC=el.checked;
  else if(k==='habpid')S.hab.pid=el.value;
  else if(k==='habmin')S.hab.min=+el.value;
  else if(k==='mcpid')S.mc=el.value;
  el.blur&&el.blur();renderMain();
});
document.addEventListener('submit',e=>{if(e.target.id==='rulesForm'){e.preventDefault();saveRules()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#modal').hidden&&!$('#modal').dataset.forced)closeModal()});
window.addEventListener('beforeunload',e=>{if((S.draft&&S.draft.dirty)||Store.pending>0){e.preventDefault();e.returnValue=''}});
window.addEventListener('online',()=>{if(S.me)renderMain()});window.addEventListener('offline',()=>{if(S.me)renderMain()});
document.addEventListener('mousemove',e=>{const t=$('#tip');const h=e.target.closest&&e.target.closest('.hit');if(h){t.textContent=h.dataset.tip;t.hidden=false;t.style.left=Math.min(e.clientX+12,innerWidth-270)+'px';t.style.top=(e.clientY-36)+'px'}else if(!t.hidden)t.hidden=true});
boot();
