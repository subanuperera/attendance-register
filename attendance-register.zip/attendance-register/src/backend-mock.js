/* In-browser stand-in for the AWS backend, used only for local testing and demos
 * (npm run dev:mock). It is never included in the AWS build.
 * It follows the same rules as the real backend: groups, permissions, conflicts. */
const KEY = 'attendance-mock-db';
const MODELS = ['Setting', 'Programme', 'Student', 'CalendarDay', 'AttendanceSlot', 'StaffProfile', 'AuditLog'];

function load() {
  try { const j = JSON.parse(localStorage.getItem(KEY)); if (j && j.tables) return j; } catch (e) { /* fresh */ }
  return {
    tables: Object.fromEntries(MODELS.map((m) => [m, {}])),
    users: { 'owner@academy.test': { password: 'Start#2026', groups: [], enabled: true, mustChange: true, name: 'Academy Owner' } },
    session: null,
  };
}
const db = load();
const save = () => localStorage.setItem(KEY, JSON.stringify(db));
const listeners = Object.fromEntries(MODELS.map((m) => [m, new Set()]));
const emit = (m) => { const items = Object.values(db.tables[m]); listeners[m].forEach((fn) => setTimeout(() => fn(items, true), 0)); };
const delay = () => new Promise((r) => setTimeout(r, 15 + Math.random() * 30));
window.__mockFail = 0;

function me() { return db.session ? { email: db.session, ...db.users[db.session] } : null; }
function err(code, message) { const e = new Error(message); e.code = code; return e; }
async function gate(model, op) {
  await delay();
  if (window.__mockFail > 0) { window.__mockFail--; throw err('unavailable', 'Could not reach the server. Check your internet connection.'); }
  const u = me();
  if (!u) throw err('forbidden', 'You do not have permission to make this change.');
  const admin = u.groups.includes('ADMINS'), lect = u.groups.includes('LECTURERS');
  if (op === 'read') { if (model === 'AuditLog' && !admin) throw err('forbidden', 'Not allowed.'); return; }
  if (admin) return;
  if (lect && model === 'AttendanceSlot' && op !== 'delete') return;
  if (lect && model === 'AuditLog' && op === 'create') return;
  throw err('forbidden', 'You do not have permission to make this change.');
}
const now = () => new Date().toISOString();

function modelApi(m) {
  return {
    async create(item) {
      await gate(m, 'create');
      const id = item.id || Math.random().toString(36).slice(2);
      if (db.tables[m][id]) throw err('conflict', 'The conditional request failed');
      db.tables[m][id] = { ...item, id, createdAt: now(), updatedAt: now() }; save(); emit(m); return db.tables[m][id];
    },
    async update(item) {
      await gate(m, 'update');
      if (!db.tables[m][item.id]) throw err('conflict', 'The conditional request failed');
      db.tables[m][item.id] = { ...db.tables[m][item.id], ...item, updatedAt: now() }; save(); emit(m); return db.tables[m][item.id];
    },
    async delete(id) {
      await gate(m, 'delete');
      const old = db.tables[m][id]; delete db.tables[m][id]; save(); emit(m); return old || null;
    },
    observe(onItems) {
      listeners[m].add(onItems);
      gate(m, 'read').then(() => onItems(Object.values(db.tables[m]), true)).catch(() => onItems([], true));
      return () => listeners[m].delete(onItems);
    },
  };
}

export const backend = {
  kind: 'mock',
  auth: {
    async current() { await delay(); const u = me(); return u && !u.mustChange ? { email: u.email, name: u.name || '', groups: u.groups.slice() } : null; },
    async refresh() { return this.current(); },
    async signIn(email, password) {
      await delay(); email = email.toLowerCase(); const u = db.users[email];
      if (!u || u.password !== password) throw err('NotAuthorizedException', 'Email or password is incorrect.');
      if (!u.enabled) throw err('NotAuthorizedException', 'This account has been disabled. Ask an administrator.');
      db.session = email; save(); return u.mustChange ? 'NEW_PASSWORD' : 'DONE';
    },
    async confirmNewPassword(pw) {
      await delay(); const u = db.users[db.session];
      if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(pw)) throw err('InvalidPasswordException', 'The password must have at least 8 characters, with upper and lower case letters, a number and a symbol.');
      u.password = pw; u.mustChange = false; save(); return 'DONE';
    },
    async signOut() { db.session = null; save(); },
    async changePassword(o, n) { const u = db.users[db.session]; if (u.password !== o) throw err('NotAuthorizedException', 'Email or password is incorrect.'); u.password = n; save(); },
    async forgotPassword() { await delay(); },
    async confirmForgot(email, code, pw) { if (code !== '123456') throw err('CodeMismatchException', 'That code is not correct. Check the email and try again.'); db.users[email.toLowerCase()].password = pw; save(); },
    async claimFirstAdmin() {
      await delay();
      if (Object.values(db.users).some((u) => u.groups.includes('ADMINS'))) throw err('forbidden', 'An administrator already exists. Ask them to give you access.');
      db.users[db.session].groups = ['ADMINS']; save();
    },
  },
  models: Object.fromEntries(MODELS.filter((m) => m !== 'AuditLog').map((m) => [m, modelApi(m)])),
  audit: {
    add: (e) => modelApi('AuditLog').create({ kind: 'log', ...e }),
    async recent(limit) {
      await gate('AuditLog', 'read');
      return { items: Object.values(db.tables.AuditLog).sort((a, b) => b.at.localeCompare(a.at) || b.createdAt.localeCompare(a.createdAt)).slice(0, limit), nextToken: null };
    },
  },
  async staff(action, a) {
    await gate('StaffProfile', 'update');
    const email = String(a.email || '').toLowerCase(); const u = db.users[email];
    const admins = () => Object.entries(db.users).filter(([k, x]) => x.groups.includes('ADMINS') && x.enabled && k !== email).length;
    const protect = () => { if (email === db.session) throw err('x', 'You cannot change or remove your own administrator account. Ask another administrator.'); if (u && u.groups.includes('ADMINS') && !admins()) throw err('x', 'Keep at least one active administrator.'); };
    if (action === 'create') { if (u) throw err('x', 'An account with this email address already exists.'); db.users[email] = { password: a.password || 'Temp#1234', groups: [a.role === 'admin' ? 'ADMINS' : 'LECTURERS'], enabled: true, mustChange: true, name: a.name }; }
    else if (!u) { if (action !== 'delete' && action !== 'disable') throw err('x', 'No sign-in account exists for this email address.'); }
    else if (action === 'update') { if (a.role) { if (a.role !== 'admin') protect(); u.groups = [a.role === 'admin' ? 'ADMINS' : 'LECTURERS']; } if (a.name) u.name = a.name; }
    else if (action === 'disable') { protect(); u.enabled = false; }
    else if (action === 'enable') u.enabled = true;
    else if (action === 'resetPassword') { u.password = a.password; u.mustChange = true; }
    else if (action === 'delete') { protect(); delete db.users[email]; }
    save(); return JSON.stringify({ ok: true });
  },
};
