# Attendance Register: AWS Amplify edition

This is the student attendance system, rebuilt to run on **Amazon Web Services (AWS)** under the institute's own AWS account. It works in any modern browser on a computer, tablet or phone. All records are stored on AWS servers, never in the browser, and staff sign in with their own email and password.

It does everything the prototype did: lecturer tick sheets, the academic calendar, the register (matching the Excel layout), progress reports, monthly summaries, the marking check, the habitual absenteeism report, and Excel/CSV exports.

---

## Part 1: Put it online (about 30 minutes, no programming needed)

You need:
- an **AWS account** for the institute (the IT department may already have one), and
- a free **GitHub account** (github.com). AWS Amplify takes the app's files from GitHub and redeploys automatically whenever they change.

### Step 1: Upload the files to GitHub
1. Sign in at **github.com** and click **New** (or **+ › New repository**).
2. Name it `attendance-register`, choose **Private**, and click **Create repository**.
3. On the next page, click **uploading an existing file**.
4. Unzip `attendance-register.zip` on your computer. Open the unzipped folder, select **everything inside it** (including the `amplify`, `src` and `public` folders), and drag it all onto the GitHub page.
   *On a Mac, press Cmd + Shift + . (full stop) in Finder first so hidden files such as `.gitignore` are included.*
5. Click **Commit changes**.

> Never upload a backup file (`attendance-backup-….json`) to GitHub. Backups contain student records.

### Step 2: Create the app in AWS Amplify
1. Sign in to the **AWS Console** (console.aws.amazon.com).
2. At the top right, set the **region** to **Asia Pacific (Mumbai) ap-south-1**, or **Asia Pacific (Singapore)** if IT prefers. This is where the student data will be stored, so record the choice for your data protection records.
3. In the search bar, type **Amplify** and open **AWS Amplify**.
4. Click **Create new app** (or **Deploy an app**), choose **GitHub**, and click **Next**. Allow AWS to access your GitHub account when asked, and give it access to the `attendance-register` repository.
5. Select the repository and the **main** branch, then click **Next**.
6. Leave the build settings as they are. AWS reads them from the `amplify.yml` file. If you're asked for a **service role**, choose **Create and use a new service role**.
7. Click **Next**, then **Save and deploy**.

The first deployment takes about 10 to 15 minutes. It creates the sign-in system, the database and the website. When it shows **Deployed**, copy the web address shown on the app page (it looks like `https://main.d1abc2xyz.amplifyapp.com`).

### Step 3: Create the first administrator account
1. In your Amplify app, open **Authentication** in the left menu, then **User management** (or **Users**), and click **Create user**.
   *If you don't see this, search for **Cognito** in the console, open **User pools**, choose the pool whose name starts with `amplifyAuthUserPool`, then go to **Users › Create user**.*
2. Enter your email address, choose **Set a password**, and type a temporary password. It needs at least 8 characters, with upper and lower case letters, a number and a symbol (for example `Welcome#2026`). Click **Create user**.
3. Open the app's web address, sign in with that email and temporary password, and choose your own password.
4. The app shows **Almost there**. Click **Set up as administrator**. This only works for the very first person, while no administrator exists.

You can add all other staff from inside the app.

### Step 4: Bring across the existing records
1. In the **previous** register (the prototype), go to **Import & backup** and click **Download backup**.
2. In the **new** register, go to **Import & backup**, and under **Bring records across from the previous register** choose that file.
3. Check the summary, then click **Copy records into the register**.
4. Wait for the green **Verified** message. It confirms that every programme, student and attendance mark in the new register matches the backup file exactly. If anything didn't copy, click the button again. It's safe to repeat and never creates duplicates.

Passwords can't be moved between systems, so the old sign-in accounts aren't copied. The app lists them so you can add those people again.

### Step 5: Add lecturers
Go to **Lecturers & access › Add lecturer**. Enter their name and email, tick their programmes and lecture slots, and click **Create account**. They'll receive an email with a temporary password, or you can set one yourself and give it to them. They choose their own password at first sign-in, and can reset it with **Forgot your password?**.

### Step 6 (optional): Use the institute's own web address
In Amplify, open **Hosting › Custom domains**, click **Add domain**, and follow the steps (for example `attendance.institute.lk`). The IT department will need to add one DNS record. AWS provides the SSL certificate (https) free of charge.

---

## Part 2: How the data is protected

| Protection | What it does |
|---|---|
| **Server-side storage** | All records live in Amazon DynamoDB in the region you chose. Nothing is kept in the browser, so clearing a browser, changing device or losing a phone loses nothing. |
| **Continuous backups (35 days)** | Point-in-time recovery is switched on for every table. AWS can restore the database to any second in the last 35 days. |
| **Deletion protection** | The database tables can't be deleted, even by accident, while this setting is on. |
| **Change history** | Every change is recorded with who made it, when, and the version before. Administrators can undo any change from **Import & backup › Change history**. Entries can't be edited or deleted. |
| **Safe saving** | If the connection drops, the app retries automatically for about 10 seconds. If it still can't save, the marks stay on screen with an "unsaved changes" warning, and the browser warns before the page is closed. |
| **Per-slot attendance records** | Each lecture slot is stored separately, so two lecturers saving different slots on the same day never overwrite each other. |
| **Backup before deleting** | Deleting a programme first downloads a full backup file automatically. |
| **Download backup** | One click saves the whole register as a file. We recommend downloading one weekly to the institute's shared drive. |
| **Sign-in and permissions** | Amazon Cognito handles passwords (they're never stored by the app). Nobody can create their own account. The server checks every request: only administrators can change programmes, students, the calendar, rules or staff, and lecturers can save attendance but can't delete it. |
| **Encryption** | HTTPS in transit. DynamoDB encrypts all data at rest. |
| **Security headers** | The site can't be embedded in other websites and loads no outside scripts or fonts (`customHttp.yml`). |

### If you ever need the 35-day restore
This is a job for the IT department. In the AWS Console, go to **DynamoDB › Tables**, choose the table (for example `AttendanceSlot-…`), then **Backups › Restore to point in time**. AWS restores into a new table, and the records can then be copied back. For everyday mistakes, use the in-app **Change history** instead. It's much quicker.

---

## Part 3: Running it

- **Updating the app:** change the files in GitHub (or upload a new version). Amplify rebuilds and redeploys automatically within about 10 minutes. Data isn't affected.
- **Cost:** for one institute with a few dozen staff, the AWS charges should be small, typically a few US dollars a month. Several services also have free allowances. We suggest setting up an **AWS Budget** alert (search for *Budgets* in the console) so IT gets an email if spending ever goes above an amount you choose.
- **Emails:** sign-in emails (invitations and password resets) are sent through Amazon Cognito's built-in sender, which has a daily limit of about 50 emails. That's plenty for normal use. If IT wants emails sent from an institute address, they can connect Amazon SES later.
- **Removing the app:** deletion protection keeps the tables (and the records) even if the Amplify app is deleted. IT must switch off deletion protection on each table before the data can be deleted.

### Things to know
- Lecturers are limited to their assigned slots and to the editing window (3 days by default) **on screen**. The server makes sure lecturers can only save attendance, not change anything else. A technically skilled lecturer could still use the underlying API to save marks for a slot that isn't theirs. Every such change appears in the change history with their name and can be undone.
- If two people save the **same** lecture slot at the same moment, the later save wins. Both versions remain in the change history.
- Excel import accepts `.xlsx` files. Old `.xls` files need to be re-saved as `.xlsx` first.

---

## For the IT department (technical summary)

- **Stack:** AWS Amplify Gen 2. The frontend is Vite with vanilla JS. Auth uses Amazon Cognito (email sign-in, groups `ADMINS` and `LECTURERS`, admin-only user creation). Data uses AWS AppSync GraphQL over DynamoDB (on-demand). A Node.js Lambda (`manage-staff`) handles user administration.
- **Infrastructure as code:** `amplify/backend.ts`, `amplify/auth/resource.ts`, `amplify/data/resource.ts`, `amplify/functions/manage-staff/`.
- **Data model:** `Setting`, `Programme`, `Student`, `CalendarDay` (one row per programme per day), `AttendanceSlot` (one row per programme, date and slot), `StaffProfile` (keyed by lower-case email), and `AuditLog` (append-only, GSI `kind`+`at`). JSON payloads are stored as strings.
- **Build:** `amplify.yml` runs Node 22, `npm install` (it doesn't use `npm ci`, because Amplify's bundled dependencies make `npm ci` fail), `ampx pipeline-deploy` (backend) and `vite build` (frontend, to `dist`).
- **Local testing without AWS:** `npm install`, then `npm run dev:mock`. Sign in as `owner@academy.test` with the password `Start#2026`. The mock keeps data in the browser and follows the same permission rules.
- **Developing against AWS:** `npx ampx sandbox` (needs AWS credentials), then `npm run dev`.
- **Staging:** connect a second branch (for example `staging`) in Amplify. It gets its own separate backend and database.
