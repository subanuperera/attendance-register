import { defineAuth } from '@aws-amplify/backend';

/**
 * Sign-in for the Attendance Register.
 *
 * - Staff sign in with their email address and a password.
 * - Nobody can create their own account: administrators add lecturers from
 *   inside the app (see backend.ts, which switches off self sign-up).
 * - Two groups decide what each person can do:
 *     ADMINS     full access to every screen and record
 *     LECTURERS  can read the register and save attendance only
 */
export const auth = defineAuth({
  loginWith: {
    email: {
      verificationEmailStyle: 'CODE',
      verificationEmailSubject: 'Attendance Register: your verification code',
      verificationEmailBody: (createCode) =>
        `Your Attendance Register verification code is ${createCode()}`,
      userInvitation: {
        emailSubject: 'Your Attendance Register account',
        emailBody: (user, code) =>
          `An account has been created for you on the Attendance Register.<br><br>` +
          `Sign-in email: ${user()}<br>Temporary password: ${code()}<br><br>` +
          `You will be asked to choose your own password the first time you sign in.`,
      },
    },
  },
  groups: ['ADMINS', 'LECTURERS'],
});
