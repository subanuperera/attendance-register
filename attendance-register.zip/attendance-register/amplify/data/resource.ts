import { type ClientSchema, a, defineData } from '@aws-amplify/backend';
import { manageStaff } from '../functions/manage-staff/resource';

/**
 * Database for the Attendance Register (Amazon DynamoDB through AWS AppSync).
 *
 * Every rule below is checked on the server, so it holds whatever browser or
 * device someone uses:
 *   - Only signed-in staff can read anything. There is no public access.
 *   - Only ADMINS can change programmes, students, the calendar, rules and staff.
 *   - LECTURERS can save attendance but cannot delete it.
 *   - The change history (AuditLog) can be added to but never edited or deleted,
 *     so an earlier version of any record can always be recovered.
 *
 * Attendance is stored one record per lecture slot (programme + date + slot),
 * so two lecturers saving different slots on the same day never overwrite
 * each other.
 */
const schema = a
  .schema({
    Setting: a
      .model({ data: a.string() })
      .authorization((allow) => [allow.authenticated().to(['read']), allow.group('ADMINS')]),

    Programme: a
      .model({ data: a.string() })
      .authorization((allow) => [allow.authenticated().to(['read']), allow.group('ADMINS')]),

    Student: a
      .model({ pid: a.string(), data: a.string() })
      .authorization((allow) => [allow.authenticated().to(['read']), allow.group('ADMINS')]),

    CalendarDay: a
      .model({ pid: a.string(), date: a.string(), data: a.string() })
      .authorization((allow) => [allow.authenticated().to(['read']), allow.group('ADMINS')]),

    AttendanceSlot: a
      .model({
        pid: a.string(),
        date: a.string(),
        slot: a.integer(),
        marks: a.string(),
        meta: a.string(),
      })
      .authorization((allow) => [
        allow.group('ADMINS'),
        allow.group('LECTURERS').to(['read', 'create', 'update']),
      ]),

    StaffProfile: a
      .model({
        email: a.string(),
        name: a.string(),
        role: a.string(),
        assign: a.string(),
        active: a.boolean(),
      })
      .authorization((allow) => [allow.authenticated().to(['read']), allow.group('ADMINS')]),

    AuditLog: a
      .model({
        kind: a.string().required(),
        at: a.string().required(),
        by: a.string(),
        byName: a.string(),
        action: a.string(),
        path: a.string(),
        before: a.string(),
        after: a.string(),
      })
      .secondaryIndexes((index) => [index('kind').sortKeys(['at']).queryField('listAuditByTime')])
      .authorization((allow) => [
        allow.group('ADMINS').to(['read', 'create']),
        allow.group('LECTURERS').to(['create']),
      ]),

    // Staff accounts are created in Amazon Cognito by a small server function,
    // because a browser must never hold the keys needed to create users.
    manageStaff: a
      .mutation()
      .arguments({
        action: a.string().required(),
        email: a.string().required(),
        name: a.string(),
        role: a.string(),
        password: a.string(),
      })
      .returns(a.string())
      .authorization((allow) => [allow.group('ADMINS')])
      .handler(a.handler.function(manageStaff)),

    // Lets the very first person who signs in become the administrator.
    // It only works while the ADMINS group is empty.
    claimFirstAdmin: a
      .mutation()
      .arguments({ action: a.string() })
      .returns(a.string())
      .authorization((allow) => [allow.authenticated()])
      .handler(a.handler.function(manageStaff)),
  });

export type Schema = ClientSchema<typeof schema>;

export const data = defineData({
  schema,
  authorizationModes: {
    defaultAuthorizationMode: 'userPool',
  },
});
