import {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminAddUserToGroupCommand,
  AdminRemoveUserFromGroupCommand,
  AdminDisableUserCommand,
  AdminEnableUserCommand,
  AdminUserGlobalSignOutCommand,
  AdminSetUserPasswordCommand,
  AdminDeleteUserCommand,
  AdminGetUserCommand,
  AdminUpdateUserAttributesCommand,
  ListUsersInGroupCommand,
  type UserType,
} from '@aws-sdk/client-cognito-identity-provider';

/**
 * Creates and manages staff sign-in accounts in Amazon Cognito.
 * Called only through the data API, which already checks that the caller is
 * an administrator (manageStaff) or signed in (claimFirstAdmin).
 */
const cognito = new CognitoIdentityProviderClient({});
const POOL = process.env.USER_POOL_ID as string;
const GROUP: Record<string, string> = { admin: 'ADMINS', lecturer: 'LECTURERS' };

type Identity = { username?: string; sub?: string; groups?: string[] | null };
type Event = {
  fieldName: string;
  arguments: { action?: string; email?: string; name?: string; role?: string; password?: string };
  identity?: Identity;
};

class UserError extends Error {}

async function adminsInPool(): Promise<UserType[]> {
  const out: UserType[] = [];
  let NextToken: string | undefined;
  do {
    const r = await cognito.send(new ListUsersInGroupCommand({ UserPoolId: POOL, GroupName: 'ADMINS', NextToken }));
    out.push(...(r.Users || []));
    NextToken = r.NextToken;
  } while (NextToken);
  return out;
}

async function usernameOf(email: string): Promise<string | null> {
  try {
    const r = await cognito.send(new AdminGetUserCommand({ UserPoolId: POOL, Username: email }));
    return r.Username || null;
  } catch (e: any) {
    if (e?.name === 'UserNotFoundException') return null;
    throw e;
  }
}

/** Stops anyone removing their own admin rights or the last active administrator. */
async function protectAdmins(targetUsername: string, caller: Identity) {
  if (caller.username && targetUsername === caller.username) {
    throw new UserError('You cannot change or remove your own administrator account. Ask another administrator.');
  }
  const admins = await adminsInPool();
  const isAdmin = admins.some((u) => u.Username === targetUsername);
  const others = admins.filter((u) => u.Username !== targetUsername && u.Enabled !== false);
  if (isAdmin && others.length === 0) {
    throw new UserError('Keep at least one active administrator.');
  }
}

export const handler = async (event: Event): Promise<string> => {
  try {
    const caller = event.identity || {};

    if (event.fieldName === 'claimFirstAdmin') {
      const admins = await adminsInPool();
      if (admins.length) throw new UserError('An administrator already exists. Ask them to give you access.');
      if (!caller.username) throw new UserError('Sign in first.');
      await cognito.send(new AdminAddUserToGroupCommand({ UserPoolId: POOL, Username: caller.username, GroupName: 'ADMINS' }));
      return JSON.stringify({ ok: true });
    }

    const { action, name, role, password } = event.arguments;
    const email = String(event.arguments.email || '').trim().toLowerCase();
    if (!email) throw new UserError('An email address is required.');

    switch (action) {
      case 'create': {
        const group = GROUP[role || 'lecturer'];
        if (!group) throw new UserError('Unknown role.');
        try {
          await cognito.send(
            new AdminCreateUserCommand({
              UserPoolId: POOL,
              Username: email,
              TemporaryPassword: password || undefined,
              DesiredDeliveryMediums: ['EMAIL'],
              UserAttributes: [
                { Name: 'email', Value: email },
                { Name: 'email_verified', Value: 'true' },
                ...(name ? [{ Name: 'name', Value: name }] : []),
              ],
            }),
          );
        } catch (e: any) {
          if (e?.name === 'UsernameExistsException') throw new UserError('An account with this email address already exists.');
          if (e?.name === 'InvalidPasswordException') throw new UserError('The temporary password does not meet the password rules: at least 8 characters with upper and lower case letters, a number and a symbol.');
          throw e;
        }
        await cognito.send(new AdminAddUserToGroupCommand({ UserPoolId: POOL, Username: email, GroupName: group }));
        return JSON.stringify({ ok: true });
      }

      case 'update': {
        // Change name and/or role.
        const uname = await usernameOf(email);
        if (!uname) throw new UserError('No sign-in account exists for this email address.');
        if (name) {
          await cognito.send(new AdminUpdateUserAttributesCommand({ UserPoolId: POOL, Username: uname, UserAttributes: [{ Name: 'name', Value: name }] }));
        }
        if (role) {
          const group = GROUP[role];
          if (!group) throw new UserError('Unknown role.');
          if (role !== 'admin') await protectAdmins(uname, caller);
          await cognito.send(new AdminAddUserToGroupCommand({ UserPoolId: POOL, Username: uname, GroupName: group }));
          for (const g of Object.values(GROUP)) {
            if (g !== group) {
              try {
                await cognito.send(new AdminRemoveUserFromGroupCommand({ UserPoolId: POOL, Username: uname, GroupName: g }));
              } catch (e: any) {
                if (e?.name !== 'UserNotFoundException' && e?.name !== 'ResourceNotFoundException') throw e;
              }
            }
          }
        }
        return JSON.stringify({ ok: true });
      }

      case 'disable': {
        const uname = await usernameOf(email);
        if (!uname) return JSON.stringify({ ok: true });
        await protectAdmins(uname, caller);
        await cognito.send(new AdminDisableUserCommand({ UserPoolId: POOL, Username: uname }));
        await cognito.send(new AdminUserGlobalSignOutCommand({ UserPoolId: POOL, Username: uname }));
        return JSON.stringify({ ok: true });
      }

      case 'enable': {
        const uname = await usernameOf(email);
        if (!uname) throw new UserError('No sign-in account exists for this email address.');
        await cognito.send(new AdminEnableUserCommand({ UserPoolId: POOL, Username: uname }));
        return JSON.stringify({ ok: true });
      }

      case 'resetPassword': {
        const uname = await usernameOf(email);
        if (!uname) throw new UserError('No sign-in account exists for this email address.');
        if (!password) throw new UserError('Enter a temporary password.');
        try {
          await cognito.send(new AdminSetUserPasswordCommand({ UserPoolId: POOL, Username: uname, Password: password, Permanent: false }));
        } catch (e: any) {
          if (e?.name === 'InvalidPasswordException') throw new UserError('The temporary password does not meet the password rules: at least 8 characters with upper and lower case letters, a number and a symbol.');
          throw e;
        }
        return JSON.stringify({ ok: true });
      }

      case 'delete': {
        const uname = await usernameOf(email);
        if (!uname) return JSON.stringify({ ok: true });
        await protectAdmins(uname, caller);
        await cognito.send(new AdminDeleteUserCommand({ UserPoolId: POOL, Username: uname }));
        return JSON.stringify({ ok: true });
      }

      default:
        throw new UserError('Unknown action.');
    }
  } catch (e: any) {
    if (e instanceof UserError) throw new Error(e.message);
    console.error(e);
    throw new Error('The account change could not be completed. Please try again.');
  }
};
