import { defineFunction } from '@aws-amplify/backend';

export const manageStaff = defineFunction({
  name: 'manage-staff',
  entry: './handler.ts',
  timeoutSeconds: 20,
  resourceGroupName: 'data',
});
