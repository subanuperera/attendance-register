import { defineBackend } from '@aws-amplify/backend';
import { PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { auth } from './auth/resource';
import { data } from './data/resource';
import { manageStaff } from './functions/manage-staff/resource';

const backend = defineBackend({ auth, data, manageStaff });

/* ---------- Sign-in ---------- */
// Only administrators can create accounts. Nobody can sign themselves up.
backend.auth.resources.cfnResources.cfnUserPool.addPropertyOverride(
  'AdminCreateUserConfig.AllowAdminCreateUserOnly',
  true,
);

/* ---------- Staff account function ---------- */
const userPool = backend.auth.resources.userPool;
backend.manageStaff.addEnvironment('USER_POOL_ID', userPool.userPoolId);
backend.manageStaff.resources.lambda.addToRolePolicy(
  new PolicyStatement({
    actions: [
      'cognito-idp:AdminCreateUser',
      'cognito-idp:AdminAddUserToGroup',
      'cognito-idp:AdminRemoveUserFromGroup',
      'cognito-idp:AdminDisableUser',
      'cognito-idp:AdminEnableUser',
      'cognito-idp:AdminUserGlobalSignOut',
      'cognito-idp:AdminSetUserPassword',
      'cognito-idp:AdminDeleteUser',
      'cognito-idp:AdminGetUser',
      'cognito-idp:AdminUpdateUserAttributes',
      'cognito-idp:ListUsersInGroup',
    ],
    resources: [userPool.userPoolArn],
  }),
);

/* ---------- Data protection ---------- */
// Every table gets:
//  - point-in-time recovery: AWS can restore any table to any second in the last 35 days
//  - deletion protection: a table cannot be deleted, even by accident, until this is switched off
const tables = backend.data.resources.cfnResources.amplifyDynamoDbTables;
for (const name of Object.keys(tables)) {
  tables[name].pointInTimeRecoveryEnabled = true;
  tables[name].deletionProtectionEnabled = true;
}
